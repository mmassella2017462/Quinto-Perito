/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.miguelmassella.controller;

import java.math.BigDecimal;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import org.miguelmassella.bean.Locales;
import org.miguelmassella.db.Conexion;
import org.miguelmassella.system.Principal;

/**
 *
 * @author migue
 * @date 13/07/2021
 * @time 23:30:54
 * @code IN5BV
*/
public class LocalesController implements Initializable {

    private  Principal escenarioPrincipal; 
    
    private ObservableList<Locales> listaLocales;
    
     private enum Operaciones {
        NUEVO, GUARDAR, EDITAR, ELIMINAR, ACTUALIZAR, CANCELAR, NINGUNO }
    
    private final String PACK_IMAGEN = "/org/miguelmassella/resource/image/";

    private Operaciones operacion = Operaciones.NINGUNO;
   
    @FXML
    private Button btnNuevo;
    @FXML
    private ImageView imgNuevo;
    @FXML
    private Button btnEliminar;
    @FXML
    private ImageView imgEliminar;
    @FXML
    private Button btnEditar;
    @FXML
    private ImageView imgEditar;
    @FXML
    private Button btnReporte;
    @FXML
    private ImageView imgReporte;
    @FXML
    private TextField txtId;
    @FXML
    private TextField txtSaldoFavor;
    @FXML
    private TextField txtMesesPendientes;
    @FXML
    private TextField txtDisponibilidad;
    @FXML
    private TextField txtSaldoContra;
    @FXML
    private TableView tblLocales;
    @FXML
    private TableColumn colId;
    @FXML
    private TableColumn colSaldoFavor;
    @FXML
    private TableColumn colSaldoContra;
    @FXML
    private TableColumn colMesesPendientes;
    @FXML
    private TableColumn colDisponibilidad;
    @FXML
    private TableColumn colValorLocal;
    @FXML
    private TableColumn colValorAdministracion;
    @FXML
    private TextField txtValorLocal;
    @FXML
    private TextField txtAdministracion;
    @FXML
    private TextField txtSaldoLiquido;   
    @FXML
    private TextField txtDisponibles;
    
    
    BigDecimal saldoFavor;
    BigDecimal saldoContra;
    


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cargarDatos();
        
    }

    public Principal getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
     @FXML
    private void mostrarClientes(MouseEvent event) {
        escenarioPrincipal.mostrarAdministracion();
    }

    
     public void cargarDatos() {
        tblLocales.setItems(getLocales());
        colId.setCellValueFactory(new PropertyValueFactory<Locales, Integer>("id"));
        colSaldoFavor.setCellValueFactory(new PropertyValueFactory<Locales, BigDecimal>("SaldoFavor"));
        colSaldoContra.setCellValueFactory(new PropertyValueFactory<Locales, BigDecimal>("SaldoContra"));
        colMesesPendientes.setCellValueFactory(new PropertyValueFactory<Locales, Integer>("mesesPendientes"));
        colDisponibilidad.setCellValueFactory(new PropertyValueFactory<Locales, Boolean>("Disponibilidad"));
        colValorLocal.setCellValueFactory(new PropertyValueFactory<Locales, BigDecimal>("ValorLocal"));
        colValorAdministracion.setCellValueFactory(new PropertyValueFactory<Locales, BigDecimal>("ValorAdministracion"));
        deshabilitarCampos(); 
    }
    
    public ObservableList<Locales> getLocales() {
        ArrayList<Locales> lista = new ArrayList<>();

        try {
            PreparedStatement pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarLocales()}");
            ResultSet rs = pstmt.executeQuery();
            int contador = 0;  
            
            while (rs.next()) {
                lista.add(new Locales(
                        rs.getInt("id"),                                               
                        rs.getBigDecimal("saldoFavor"),
                        rs.getBigDecimal("saldoContra"),
                        rs.getInt("mesesPendientes"),
                        rs.getBoolean("disponibilidad"),  
                        rs.getBigDecimal("valorLocal"),
                        rs.getBigDecimal("valorAdministracion"))
                );
                if(rs.getBoolean("disponibilidad") == true){
                    contador++;
                }
                
            }
            txtDisponibles.setText(String.valueOf(contador));
            rs.close();
            pstmt.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        listaLocales = FXCollections.observableArrayList(lista);
        return listaLocales;
    }

    
    
     private void agregarLocales() {
        Locales registro = new Locales();
        registro.setMesesPendientes(Integer.valueOf(txtMesesPendientes.getText()));
        Boolean x = new Boolean(txtDisponibilidad.getText());
        registro.setDisponibilidad(x);
        BigDecimal d = new BigDecimal(txtSaldoFavor.getText());
        registro.setSaldoFavor(d);
        BigDecimal c = new BigDecimal(txtSaldoContra.getText());
        registro.setSaldoContra(c);
        BigDecimal b = new BigDecimal(txtValorLocal.getText());
        registro.setValorLocal(b);
        BigDecimal a = new BigDecimal(txtAdministracion.getText());
        registro.setValorAdministracion(a);

        try {
            PreparedStatement stmt;
            stmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_AgregarLocales(?,?,?,?,?,?) }");
            stmt.setBigDecimal(1, registro.getSaldoFavor());
            stmt.setBigDecimal(2, registro.getSaldoContra());
            stmt.setInt(3, registro.getMesesPendientes());
            stmt.setBoolean(4, registro.isDisponibilidad());
            stmt.setBigDecimal(5, registro.getValorLocal());
            stmt.setBigDecimal(6, registro.getValorAdministracion());
            stmt.execute();
            System.out.println(stmt.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    
     private void editarLocales() {

        Locales registro = (Locales) tblLocales.getSelectionModel().getSelectedItem();
        registro.setMesesPendientes(Integer.valueOf(txtMesesPendientes.getText()));
        Boolean x = new Boolean(txtDisponibilidad.getText());
        registro.setDisponibilidad(x);
        BigDecimal d = new BigDecimal(txtSaldoFavor.getText());
        registro.setSaldoFavor(d);
        BigDecimal c = new BigDecimal(txtSaldoContra.getText());
        registro.setSaldoContra(c);
        BigDecimal b = new BigDecimal(txtValorLocal.getText());
        registro.setValorLocal(b);
        BigDecimal a = new BigDecimal(txtAdministracion.getText());
        registro.setValorAdministracion(a);

        try {
            PreparedStatement stmt;

            stmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_EditarLocales(?,?,?,?,?,?,?)}");

            stmt.setInt(1,((Locales)tblLocales.getSelectionModel().getSelectedItem()).getId());
            stmt.setBigDecimal(2,((Locales)tblLocales.getSelectionModel().getSelectedItem()).getSaldoFavor());
            stmt.setBigDecimal(3,((Locales)tblLocales.getSelectionModel().getSelectedItem()).getSaldoContra());
            stmt.setInt(4,((Locales)tblLocales.getSelectionModel().getSelectedItem()).getMesesPendientes());
            stmt.setBoolean(5,((Locales)tblLocales.getSelectionModel().getSelectedItem()).isDisponibilidad());
            stmt.setBigDecimal(6,((Locales)tblLocales.getSelectionModel().getSelectedItem()).getValorLocal());
            stmt.setBigDecimal(7,((Locales)tblLocales.getSelectionModel().getSelectedItem()).getValorAdministracion());
            stmt.execute();
            System.out.println(stmt.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
      private void eliminarLocales() {

          try {
                PreparedStatement stmt;
                stmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_EliminarLocales(?)}");
                stmt.setInt(1, ((Locales) tblLocales.getSelectionModel().getSelectedItem()).getId());
                stmt.execute();
                System.out.println(stmt.toString());
            } catch (Exception e) {
                e.printStackTrace();
            }  
    }
    

       private void mostrarSaldoLiquido(){      
            txtSaldoLiquido.setText(String.valueOf(saldoFavor.subtract(saldoContra)));   
    }
      
    
    @FXML
    private void seleccionarElemento(MouseEvent event) {
        
        if (tblLocales.getSelectionModel().getSelectedItem() != null) {

            txtId.setText(String.valueOf(((Locales) tblLocales.getSelectionModel().getSelectedItem()).getId()));
            txtSaldoFavor.setText(String.valueOf(((Locales) tblLocales.getSelectionModel().getSelectedItem()).getSaldoFavor()));
           
            
            saldoFavor = ((Locales) tblLocales.getSelectionModel().getSelectedItem()).getSaldoFavor();
            txtSaldoContra.setText(String.valueOf(((Locales) tblLocales.getSelectionModel().getSelectedItem()).getSaldoContra()));
           
            saldoContra = ((Locales) tblLocales.getSelectionModel().getSelectedItem()).getSaldoContra();
            
            txtMesesPendientes.setText(String.valueOf(((Locales) tblLocales.getSelectionModel().getSelectedItem()).getMesesPendientes()));
            txtDisponibilidad.setText(String.valueOf(((Locales) tblLocales.getSelectionModel().getSelectedItem()).isDisponibilidad()));
            txtValorLocal.setText(String.valueOf(((Locales) tblLocales.getSelectionModel().getSelectedItem()).getValorLocal()));
            txtAdministracion.setText(String.valueOf(((Locales) tblLocales.getSelectionModel().getSelectedItem()).getValorAdministracion()));

           
            
         mostrarSaldoLiquido();
         
        } else {
            Alert vacio = new Alert(Alert.AlertType.ERROR);
            vacio.setTitle("Error");
            vacio.setContentText("Este campo esta vacio");
            vacio.setHeaderText(null);
            vacio.show();
        }
       
        
        
    }
    
    
    
    
    
    
    
    
     public boolean existeElementoSeleccionado() {

        if (tblLocales.getSelectionModel().getSelectedItem() == null) {
            return false;
        } else {
            return true;
        }
    }
    
    
    
      private void habilitarCampos() {
        txtId.setEditable(false);
        txtSaldoFavor.setEditable(true);
        txtSaldoContra.setEditable(true);
        txtMesesPendientes.setEditable(true);
        txtDisponibilidad.setEditable(true);
        txtAdministracion.setEditable(true);
        txtValorLocal.setEditable(true);
    }

    private void deshabilitarCampos() {
        txtId.setEditable(false);
        txtSaldoFavor.setEditable(false);
        txtValorLocal.setEditable(false);
        txtSaldoContra.setEditable(false);
        txtMesesPendientes.setEditable(false);
        txtAdministracion.setEditable(false);
        txtDisponibilidad.setEditable(false);
        txtSaldoLiquido.setEditable(false);
        txtDisponibles.setEditable(false);
        
    }

    private void limpiarCampos() {
        txtId.clear();
        txtSaldoFavor.clear();
        txtValorLocal.clear();
        txtSaldoContra.clear();
        txtMesesPendientes.clear();
        txtAdministracion.clear();
        txtDisponibilidad.clear();
    }

    
    @FXML
    private void nuevo(ActionEvent event) {
        System.out.println("Operaciones" + operacion);
        
                switch (operacion) {
            case NINGUNO:
                habilitarCampos();
                btnNuevo.setText("Guardar");
                btnEliminar.setText("Cancelar");
                imgNuevo.setImage(new Image(PACK_IMAGEN + "Guardar.png"));
                imgEliminar.setImage(new Image(PACK_IMAGEN + "Cancelar.png"));
                btnEditar.setDisable(true);
                btnReporte.setDisable(true);
                operacion = Operaciones.GUARDAR;
                break;
              
            case GUARDAR:
               if (txtMesesPendientes.getText().length() != 0
                        && txtDisponibilidad.getText().length() != 0
                        && txtSaldoFavor.getText().length() != 0
                        && txtValorLocal.getText().length() != 0
                        && txtSaldoContra.getText().length() != 0
                        && txtAdministracion.getText().length() != 0) {
                    agregarLocales();
                    cargarDatos();
                    deshabilitarCampos();
                    limpiarCampos();
                    btnNuevo.setText("Nuevo");
                    btnEliminar.setText("Eliminar");
                    btnEditar.setDisable(false);
                    btnReporte.setDisable(false);
                    operacion = Operaciones.NINGUNO;
                    
                } else {
                    Alert a1 = new Alert(Alert.AlertType.INFORMATION);
                    a1.setTitle("Tenemos un Problema");
                    a1.setHeaderText(null);
                    a1.setContentText("Debe llenar los datos solicitados");
                    a1.showAndWait();
                }
                break;                
        }
        System.out.println("Operación: " + operacion);
        
        
        
    }

    @FXML
    private void eliminar(ActionEvent event) {
        System.out.println("Operacion" + operacion);

        switch (operacion) {
            case GUARDAR:
                btnNuevo.setText("Nuevo");
                btnEliminar.setText("Eliminar");
                
                imgNuevo.setImage(new Image(PACK_IMAGEN + "Agregar.png"));
                imgEliminar.setImage(new Image(PACK_IMAGEN + "Eliminar.png"));
                
                btnEditar.setDisable(false);
                btnReporte.setDisable(false);
                limpiarCampos();
                habilitarCampos();
                operacion = Operaciones.NINGUNO;
                break;
            case NINGUNO://Elimanación
                if (existeElementoSeleccionado()) {
                                        
                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("¿Desea eliminar este registro?");
                     Optional<ButtonType> respuesta = alert.showAndWait();
                    if (respuesta.get() == ButtonType.OK) {
                        eliminarLocales();
                        limpiarCampos();
                        cargarDatos();                        
                    }
                    
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Es necesario que seleccione un registro");
                    alert.show();
                }

                break;
                        
        }
    }

    @FXML
    private void editar(ActionEvent event) {
         System.out.println("Operacion: " + operacion);

        switch (operacion) {
            case NINGUNO:
                if (tblLocales.getSelectionModel().getSelectedItem() != null) {
                    habilitarCampos();
                    btnEditar.setText("Actualizar");
                    btnReporte.setText("Cancelar");
                    
                    imgEditar.setImage(new Image(PACK_IMAGEN + "Guardar.png"));
                    imgReporte.setImage(new Image(PACK_IMAGEN + "Cancelar.png"));
                    
                    btnNuevo.setDisable(true);
                    btnEliminar.setDisable(true);
                    operacion = Operaciones.ACTUALIZAR;
                } else {
                    Alert a1 = new Alert(Alert.AlertType.INFORMATION);
                    a1.setTitle("Parece que hay un error");
                    a1.setHeaderText(null);
                    a1.setContentText("Seleccion un registro antes de continuar");
                    a1.showAndWait();
                }
                break;
            case ACTUALIZAR:
                editarLocales();
                limpiarCampos();
                cargarDatos();
                deshabilitarCampos();
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                btnEditar.setText("Editar");
                btnReporte.setText("Reporte");
                operacion = Operaciones.NINGUNO;
                break;
        }
    }

    @FXML
    private void reporte(ActionEvent event) {
         System.out.println("Operacion " + operacion);
        switch (operacion) {
            case ACTUALIZAR:
                btnEditar.setText("Editar");
                btnReporte.setText("Reporte");
                
                imgReporte.setImage(new Image(PACK_IMAGEN + "Reporte.png"));
                imgEditar.setImage(new Image(PACK_IMAGEN + "Editar.png"));
                
                btnEditar.setDisable(false);
                btnReporte.setDisable(false);
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                cargarDatos();
                limpiarCampos();
                deshabilitarCampos();
                operacion = Operaciones.NINGUNO;
        }
        
        
        
    }

    

   
    
    
    
    
    
    
    
    
    
    
    
    
   
}
