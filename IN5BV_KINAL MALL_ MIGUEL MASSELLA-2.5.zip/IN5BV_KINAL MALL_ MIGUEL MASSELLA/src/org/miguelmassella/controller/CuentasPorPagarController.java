/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.miguelmassella.controller;

import com.jfoenix.controls.JFXDatePicker;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import org.miguelmassella.bean.Administracion;
import org.miguelmassella.bean.CuentasPorPagar;
import org.miguelmassella.bean.Proveedores;
import org.miguelmassella.db.Conexion;
import org.miguelmassella.system.Principal;

/**
 *
 * @author migue
 * @date 22/07/2021
 * @time 00:47:00
 * @code IN5BV
*/
public class CuentasPorPagarController implements Initializable {

    private Principal escenarioPrincipal;
    private final String PACK_IMAGEN = "/org/miguelmassella/resource/image/" ;
    
    private ObservableList<Administracion> listaAdministracion;
    private ObservableList<Proveedores> listaProveedores;
    private ObservableList<CuentasPorPagar> listaCuentasPorPagar;
    
    
    private enum Operaciones {
        NUEVO, GUARDAR, ACTUALIZAR, ELIMINAR, CANCELAR, NINGUNO}
    
    private Operaciones operacion = Operaciones.NINGUNO;
    
    @FXML
    private Button btnNuevo;
    @FXML
    private ImageView imgNuevo;
    @FXML
    private Button btnEliminar;
    @FXML
    private ImageView imgEliminar;
    @FXML
    private Button btnEditar;
    @FXML
    private ImageView imgEditar;
    @FXML
    private Button btnReporte;
    @FXML
    private ImageView imgReporte;
    @FXML
    private TableView tblCuentasPorPagar;
    @FXML
    private TableColumn colId;
    @FXML
    private TableColumn colNumeroFactura;
    @FXML
    private TableColumn colFechaLimitePago;
    @FXML
    private TableColumn colEstadoPago;
    @FXML
    private TableColumn colValorNetoPago;
    @FXML
    private TableColumn colIdAdministracion;
    @FXML
    private TableColumn colIdProveedor;
    @FXML
    private TextField txtId;
    @FXML
    private TextField txtNumeroFactura;
    @FXML
    private TextField txtValorNetoPago;
    @FXML
    private ComboBox cmbProveedor;
    @FXML
    private ComboBox cmbAdministracion;
    @FXML
    private JFXDatePicker dpFechaLimite;
    @FXML
    private ComboBox cmbEstadoPago;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        Locale locale = new Locale("es", "GT");
        Locale.setDefault(locale);
        
        dpFechaLimite.setEditable(false);
        
        ObservableList<String> listaOpciones = FXCollections.observableArrayList( "PENDIENTE","CANCELADO");
        cmbEstadoPago.getItems().addAll(listaOpciones);
        
        cargarDatos();
    }

    public Principal getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
     @FXML
    private void mostrarProveedores(MouseEvent event) {
        escenarioPrincipal.mostrarProveedores();
    }
    
    
    public ObservableList<CuentasPorPagar> getCuentasPorPagar() {
        ArrayList<CuentasPorPagar> listado = new ArrayList<>();
        
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarCuentasPorPagar}");
            System.out.println(pstmt);    
            rs = pstmt.executeQuery();
            
            while(rs.next()) {
                listado.add(new CuentasPorPagar(
                        rs.getInt("id"), 
                        rs.getString("numeroFactura"), 
                        rs.getDate("fechaLimitePago"), 
                        rs.getString("estadoPago"), 
                        rs.getBigDecimal("valorNetoPago"), 
                        rs.getInt("idAdministracion"), 
                        rs.getInt("idProveedor") 
                    )
                );
            }
            
            listaCuentasPorPagar = FXCollections.observableArrayList(listado);
            
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar consultar la tabla Cuentas por pagar de la base de datos.");
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
                pstmt.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        
        return listaCuentasPorPagar;
    }
    
    
     public ObservableList<Administracion> getAdministracion() {
        ArrayList<Administracion> listado = new ArrayList<Administracion>();
        PreparedStatement stmt = null;
        ResultSet resultado = null;
        try {
            
            stmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarAdministracion()}");
            resultado = stmt.executeQuery();

            while (resultado.next()) {
                listado.add(new Administracion(
                        resultado.getInt("id"),
                        resultado.getString("direccion"),
                        resultado.getString("telefono")
                )
                );
            }
            listaAdministracion = FXCollections.observableArrayList(listado);
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar consultar la tabla Administración en la base de datos.");
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                resultado.close();
                stmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return listaAdministracion;
    }
    
     public ObservableList<Proveedores> getProveedores() {
        ArrayList<Proveedores> lista = new ArrayList<>();

        try {
            PreparedStatement pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarProveedores()}");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                lista.add(new Proveedores(
                        rs.getInt("id"),
                        rs.getString("nit"),
                        rs.getString("servicioPrestado"),
                        rs.getString("telefono"),
                        rs.getString("direccion"),
                        rs.getBigDecimal("saldoFavor"),
                        rs.getBigDecimal("saldoContra"))
                );
            }

            rs.close();
            pstmt.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        listaProveedores = FXCollections.observableArrayList(lista);
        return listaProveedores;
    }
    
    
    
    
    public Administracion buscarAdministracion(int id) {
        Administracion administracion = null;
        
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_BuscarAdministracion(?)}");
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                administracion = new Administracion(
                        rs.getInt("id"), 
                        rs.getString("direccion"), 
                        rs.getString("telefono")
                );
            }
            
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar buscar una Administracion con el ID " + id);
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
                pstmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
                    
        return administracion;
    }
    
     public Proveedores buscarProveedores(int id) {
        Proveedores proveedores = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_BuscarProveedores(?)}");
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                proveedores = new Proveedores(
                        rs.getInt("id"),
                        rs.getString("nit"),
                        rs.getString("servicioPrestado"),
                        rs.getString("telefono"),
                        rs.getString("direccion"),
                        rs.getBigDecimal("saldoFavor"),
                        rs.getBigDecimal("saldoContra")
                );
            }
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar consultar la tabla proveedores del registro con el ID: " + id);
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
                pstmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return proveedores;
    }    
    
    public void agregarCuentasPorPagar() {
        CuentasPorPagar cuentaPagar = new CuentasPorPagar();
        
        cuentaPagar.setNumeroFactura(txtNumeroFactura.getText());
        cuentaPagar.setFechaLimitePago(Date.valueOf(dpFechaLimite.getValue()));
        cuentaPagar.setEstadoPago(cmbEstadoPago.getValue().toString());
        cuentaPagar.setValorNetoPago(new BigDecimal(txtValorNetoPago.getText()));
        cuentaPagar.setIdAdministracion(((Administracion)cmbAdministracion.getSelectionModel().getSelectedItem()).getId());
        cuentaPagar.setIdProveedor(((Proveedores)cmbProveedor.getSelectionModel().getSelectedItem()).getId());
       
        PreparedStatement pstmt = null;
        
        try {
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_AgregarCuentasPorPagar(?, ?, ?, ?, ?, ? )}");
            pstmt.setString(1, cuentaPagar.getNumeroFactura());
            pstmt.setDate(2, cuentaPagar.getFechaLimitePago());
            pstmt.setString(3, cuentaPagar.getEstadoPago());
            pstmt.setBigDecimal(4, cuentaPagar.getValorNetoPago());
            pstmt.setInt(5, cuentaPagar.getIdAdministracion());
            pstmt.setInt(6, cuentaPagar.getIdProveedor());
            
            System.out.println(pstmt);
            
            pstmt.execute();
            
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar agregar una nueva Cuenta por cobrar");
            e.printStackTrace();
        } finally {
            try {
                pstmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
      public void editarCuentasPorPagar(){
    
        CuentasPorPagar cuentaPagar = new CuentasPorPagar();
        cuentaPagar.setId(Integer.parseInt(txtId.getText()));
        cuentaPagar.setNumeroFactura(txtNumeroFactura.getText());
        cuentaPagar.setFechaLimitePago(Date.valueOf(dpFechaLimite.getValue()));
        cuentaPagar.setEstadoPago(cmbEstadoPago.getValue().toString());
        cuentaPagar.setValorNetoPago(new BigDecimal(txtValorNetoPago.getText()));
        cuentaPagar.setIdAdministracion(((Administracion)cmbAdministracion.getSelectionModel().getSelectedItem()).getId());
        cuentaPagar.setIdProveedor(((Proveedores)cmbProveedor.getSelectionModel().getSelectedItem()).getId());
        
        PreparedStatement pstmt = null;
        
        try {
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_EditarCuentasPorPagar(?, ?, ?, ?, ?, ?, ?)}");
            
            pstmt.setInt(1, cuentaPagar.getId());

            pstmt.setString(2, cuentaPagar.getNumeroFactura());
            pstmt.setDate(3, cuentaPagar.getFechaLimitePago());
            pstmt.setString(4, cuentaPagar.getEstadoPago());
            pstmt.setBigDecimal(5, cuentaPagar.getValorNetoPago());
            pstmt.setInt(6, cuentaPagar.getIdAdministracion());
            pstmt.setInt(7, cuentaPagar.getIdProveedor());
            
            System.out.println(pstmt);
            
            pstmt.execute();
            
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar agregar una nueva Cuenta por cobrar");
            e.printStackTrace();
        } finally {
            try {
                pstmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    
    } public void eliminarCuentasPorPagar() {
        
        if (existeElementoSeleccionado()) {
            
            CuentasPorPagar cuentasPorPagar = (CuentasPorPagar) tblCuentasPorPagar.getSelectionModel().getSelectedItem();
            
            System.out.println(cuentasPorPagar);
            
            PreparedStatement pstmt = null;
            
            try {
                pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_EliminarCuentasPorPagar(?)}");
                
                pstmt.setInt(1,((CuentasPorPagar) tblCuentasPorPagar.getSelectionModel().getSelectedItem()).getId());

                
                System.out.println(pstmt);
                
                pstmt.execute();
                
            } catch (SQLException e) {
                System.err.println("\nSe produjo un error al intentar eliminar el registro con el id " + cuentasPorPagar.getId());
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    pstmt.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        
    }
    
    
    
     public void cargarDatos(){
    
        tblCuentasPorPagar.setItems(getCuentasPorPagar());
        
        colId.setCellValueFactory(new PropertyValueFactory<CuentasPorPagar, Integer>("id"));
        colNumeroFactura.setCellValueFactory(new PropertyValueFactory<CuentasPorPagar, String>("numeroFactura"));
        
        //datePicker
        colFechaLimitePago.setCellValueFactory(new PropertyValueFactory<CuentasPorPagar, Date>("fechaLimitePago"));
        
        colEstadoPago.setCellValueFactory(new PropertyValueFactory<CuentasPorPagar, String>("estadoPago"));
        colValorNetoPago.setCellValueFactory(new PropertyValueFactory<CuentasPorPagar, BigDecimal>("valorNetoPago"));
        colIdAdministracion.setCellValueFactory(new PropertyValueFactory<CuentasPorPagar, Integer>("idAdministracion"));
        colIdProveedor.setCellValueFactory(new PropertyValueFactory<CuentasPorPagar, Integer>("idProveedor"));
        
        cmbAdministracion.setItems(getAdministracion());
        cmbProveedor.setItems(getProveedores());
    }
    
    
     public boolean existeElementoSeleccionado() {

        if (tblCuentasPorPagar.getSelectionModel().getSelectedItem() == null) {
            return false;
        } else {
            return true;
        }
    }

    
     @FXML
    private void seleccionarElemento(MouseEvent event) {
         if(existeElementoSeleccionado()){
        
            txtId.setText(String.valueOf(((CuentasPorPagar) tblCuentasPorPagar.getSelectionModel().getSelectedItem()).getId()));  
            txtNumeroFactura.setText((((CuentasPorPagar) tblCuentasPorPagar.getSelectionModel().getSelectedItem()).getNumeroFactura()));            
            dpFechaLimite.setValue(((CuentasPorPagar) tblCuentasPorPagar.getSelectionModel().getSelectedItem()).getFechaLimitePago().toLocalDate());            
            txtValorNetoPago.setText(String.valueOf(((CuentasPorPagar) tblCuentasPorPagar.getSelectionModel().getSelectedItem()).getValorNetoPago()));
            cmbEstadoPago.setValue(((CuentasPorPagar)tblCuentasPorPagar.getSelectionModel().getSelectedItem()).getEstadoPago());
            cmbAdministracion.getSelectionModel().select(buscarAdministracion(((CuentasPorPagar) tblCuentasPorPagar.getSelectionModel().getSelectedItem()).getIdAdministracion()));
            cmbProveedor.getSelectionModel().select(buscarProveedores(((CuentasPorPagar) tblCuentasPorPagar.getSelectionModel().getSelectedItem()).getIdProveedor()));
        } else {
            Alert vacio = new Alert(Alert.AlertType.ERROR);
            vacio.setTitle("Error");
            vacio.setContentText("Este campo esta vacio");
            vacio.setHeaderText(null);
            vacio.show();
        }
    }
    
    
     public void activarControles(){
    
        txtId.setDisable(true);
        txtId.setDisable(false);
        
        txtNumeroFactura.setDisable(false);
        txtNumeroFactura.setEditable(true);
        
        dpFechaLimite.setDisable(false);
        
        
        
        txtValorNetoPago.setDisable(false);
        txtValorNetoPago.setEditable(true);
        
        cmbAdministracion.setDisable(false);
        cmbProveedor.setDisable(false);
        cmbEstadoPago.setDisable(false);
    }
    
    public void desactivarControles(){
    
        txtId.setDisable(false);
        txtId.setEditable(true);
        
        txtNumeroFactura.setDisable(true);
        txtNumeroFactura.setEditable(false);
        
        dpFechaLimite.setDisable(true);
        
        
        
        txtValorNetoPago.setDisable(true);
        txtValorNetoPago.setEditable(false);
        
        cmbAdministracion.setDisable(true);
        cmbProveedor.setDisable(true);
        cmbEstadoPago.setDisable(true);
    }
    
    public void limpiarControles(){
    
        txtId.clear();
        txtNumeroFactura.clear();
        
        dpFechaLimite.getEditor().clear();
        dpFechaLimite.setValue(null);
        
        
        txtValorNetoPago.clear();
        cmbAdministracion.valueProperty().set(null);
        cmbProveedor.valueProperty().set(null);
        cmbEstadoPago.setValue(null);
    }
    
    
    
    
     public boolean validarDecimal(String numero){
        String patron = "^\\d{1,8}([.]\\d{1,2})?$";
        Pattern pattern = Pattern.compile(patron);
        Matcher matcher = pattern.matcher(numero);
        return matcher.matches();
    
    }
    
    
    
    
    
    

    @FXML
    private void nuevo(ActionEvent event) {
          switch (operacion) {
            case NINGUNO:
                activarControles();
                limpiarControles();
                
                btnNuevo.setText("Guardar");
              
                
                btnEditar.setDisable(true);
                
                btnEliminar.setText("Cancelar");
                
                imgNuevo.setImage(new Image( PACK_IMAGEN + "Guardar.png"));
                imgEliminar.setImage(new Image(PACK_IMAGEN + "Cancelar.png"));
                
                btnReporte.setDisable(true);
                
                operacion = Operaciones.GUARDAR;
                break;
                
            case GUARDAR:

                ArrayList<TextField> listaTextField = new ArrayList<>();
                listaTextField.add(txtNumeroFactura);
                listaTextField.add(txtValorNetoPago);
                

                ArrayList<ComboBox> listaComboBox = new ArrayList<>();
                listaComboBox.add(cmbAdministracion);
                listaComboBox.add(cmbProveedor);
                listaComboBox.add(cmbEstadoPago);

                if (escenarioPrincipal.validar(listaTextField, listaComboBox)) {
                    if (validarDecimal(txtValorNetoPago.getText())) {

                        agregarCuentasPorPagar();
                        cargarDatos();
                        desactivarControles();
                        limpiarControles();

                        btnNuevo.setText("Nuevo");
                        imgNuevo.setImage(new Image(PACK_IMAGEN + "Agregar.png"));

                        btnEliminar.setText("Eliminar");
                        imgEliminar.setImage(new Image(PACK_IMAGEN + "Eliminar.png"));

                        btnEditar.setDisable(false);
                        btnReporte.setDisable(false);

                        operacion = Operaciones.NINGUNO;
                    } else {
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("KINAL MALL");
                        alert.setHeaderText(null);
                        alert.setContentText("El campo Valor Neto Pago solo acepta numeros, numeros con dos decimales y de ocho digitos");
                        alert.show();
                    }

                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Por favor llene todos lo campos de textos");
                    alert.show();

                }

                break;
        }

    }

    @FXML
    private void eliminar(ActionEvent event) {
         switch (operacion) {
            case GUARDAR:
                
                btnNuevo.setText("Nuevo");
              
                
                
                btnEliminar.setText("Eliminar");
                
                imgNuevo.setImage(new Image(PACK_IMAGEN + "Agregar.png"));
                imgEliminar.setImage(new Image(PACK_IMAGEN + "Eliminar.png"));
                
                btnEditar.setDisable(false);
                btnReporte.setDisable(false);
                
                limpiarControles();
                desactivarControles();
                
                operacion = Operaciones.NINGUNO;
                break;
            case NINGUNO: // Eliminación
                if (existeElementoSeleccionado()) {
                                        
                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("¿Está seguro que desea eliminar este registro?");
                    
                    Optional<ButtonType> respuesta = alert.showAndWait();
                    
                    if (respuesta.get() == ButtonType.OK) {
                        eliminarCuentasPorPagar();
                        limpiarControles();
                        cargarDatos();                        
                    }
                    
                    
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Seleccione primero un registro para eliminar");
                    alert.show();
                }

                break;
        }
    
    
    
    
    }

    @FXML
    private void editar(ActionEvent event) {
        
        switch (operacion) {
            case NINGUNO:
                if (existeElementoSeleccionado()) {
                    activarControles();
                    
                    btnEditar.setText("Actualizar");
                    
                    
                    btnReporte.setText("Cancelar");
                    imgEditar.setImage(new Image(PACK_IMAGEN + "Guardar.png"));
                    imgReporte.setImage(new Image(PACK_IMAGEN + "Cancelar.png"));
                    
                    btnNuevo.setDisable(true);
                    btnEliminar.setDisable(true);
                    
                    operacion = Operaciones.ACTUALIZAR;
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Antes de continuar, selecciona un registro");
                    alert.show();
                }

                break;
                
            case ACTUALIZAR:
                
                ArrayList<TextField> listaTextField = new ArrayList<>();
                listaTextField.add(txtId);
                listaTextField.add(txtNumeroFactura);
                listaTextField.add(txtValorNetoPago);
               

                ArrayList<ComboBox> listaComboBox = new ArrayList<>();
                listaComboBox.add(cmbAdministracion);
                listaComboBox.add(cmbProveedor);
                listaComboBox.add(cmbEstadoPago);

                if (escenarioPrincipal.validar(listaTextField, listaComboBox)) {
                    if (validarDecimal(txtValorNetoPago.getText())) {
                        editarCuentasPorPagar();
                        limpiarControles();
                        desactivarControles();
                        cargarDatos();

                        btnNuevo.setDisable(false);
                        btnEliminar.setDisable(false);

                        btnEditar.setText("Editar");

                        btnReporte.setText("Reporte");
                        imgReporte.setImage(new Image(PACK_IMAGEN + "Reporte.png"));
                        imgEditar.setImage(new Image(PACK_IMAGEN + "Editar.png"));

                        operacion = Operaciones.NINGUNO;
                        break;
                    } else {
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("KINAL MALL");
                        alert.setHeaderText(null);
                        alert.setContentText("El campo Valor Neto Pago solo acepta numeros, numeros con dos decimales y de ocho digitos");
                        alert.show();
                    }

                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Verifique que tenga todos los datos necesarios");
                    alert.show();

                }

        }


    }

    @FXML
    private void reporte(ActionEvent event) {
         switch (operacion) {
            case ACTUALIZAR:
                limpiarControles();
                desactivarControles();
                //cargarDatos();
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                
                btnEditar.setText("Editar");
                btnReporte.setText("Reporte");
                
                imgReporte.setImage(new Image(PACK_IMAGEN + "Reporte.png"));
                imgEditar.setImage(new Image(PACK_IMAGEN + "Editar.png"));
                
                operacion = Operaciones.NINGUNO;
                break;
        }
        
        
        
    }

   
        
    }

   


