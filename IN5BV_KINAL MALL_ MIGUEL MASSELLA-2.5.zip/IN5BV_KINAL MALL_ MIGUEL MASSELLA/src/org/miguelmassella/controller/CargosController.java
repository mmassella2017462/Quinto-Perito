/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.miguelmassella.controller;

import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import org.miguelmassella.bean.Administracion;
import org.miguelmassella.bean.Cargos;
import org.miguelmassella.db.Conexion;
import org.miguelmassella.system.Principal;

/**
 *
 * @author migue
 * @date 17/07/2021
 * @time 01:36:04
 * @code IN5BV
*/
public class CargosController  implements Initializable{

    private Principal escenarioPrincipal;
    
    private ObservableList<Cargos> listadoCargos;
    
    private final String PACK_IMAGEN = "/org/miguelmassella/resource/image/" ;
    
    private enum Operaciones{NUEVO, GUARDAR, EDITAR, ELIMINAR, 
                                ACTUALIZAR, CANCELAR, NINGUNO};
    
    private Operaciones operacion = Operaciones.NINGUNO;
    
    
    @FXML
    private TextField txtId;
    @FXML
    private TextField txtNombre;
    @FXML
    private TableView tblCargos;
    @FXML
    private TableColumn colId;
    @FXML
    private TableColumn colNombre;
    @FXML
    private Button btnNuevo;
    @FXML
    private ImageView imgNuevo;
    @FXML
    private Button btnEditar;
    @FXML
    private ImageView imgEditar;
    @FXML
    private Button btnEliminar;
    @FXML
    private ImageView imgEliminar;
    @FXML
    private Button btnReporte;
    @FXML
    private ImageView imgReporte;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        CargarDatos();
        
    }

    public Principal getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    

    @FXML
    private void mostrarAdministracion(MouseEvent event) {
        escenarioPrincipal.mostrarAdministracion();
    }

    
    
     public ObservableList<Cargos> getCargos(){
        
        ArrayList<Cargos> listado = new ArrayList<Cargos>();
        
        
        try {   
            //CallableStatement stmt;
            PreparedStatement stmt;
            stmt= Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarCargos()}");
            ResultSet resultado = stmt.executeQuery();
            
            while (resultado.next()){
                listado.add(new Cargos(
                                resultado.getInt("id"),
                                resultado.getString("nombre")
                )   );
            }
            
            resultado.close();
            stmt.close();
            
            
        }catch( SQLException e){
            e.printStackTrace();
        } 
       listadoCargos = FXCollections.observableArrayList(listado);
       
        return listadoCargos;
                
    }
    
     public void CargarDatos(){
       
       tblCargos.setItems(getCargos());
       colId.setCellValueFactory( new PropertyValueFactory<Administracion, Integer>("id"));
       colNombre.setCellValueFactory(new PropertyValueFactory<Administracion, String>("nombre"));
    }

     
       public void agregarCargos() {

        Cargos registro = new Cargos();
        registro.setNombre(txtNombre.getText());

        try {
            PreparedStatement stmt;
            stmt = Conexion.getInstance().getConexion().prepareCall("{call sp_AgregarCargos(?)}");
            stmt.setString(1, registro.getNombre());
            stmt.execute();
        } catch (Exception e) {
            e.printStackTrace(); }
    }

       private void editarCargos() {

        Cargos registro = new Cargos();

        registro.setId(Integer.parseInt(txtId.getText()));
        registro.setNombre(txtNombre.getText());
       

        try {
            PreparedStatement stmt;
            stmt = Conexion.getInstance().getConexion().prepareCall("{call sp_EditarCargos(?, ?)}");
            stmt.setInt(1, registro.getId());
            stmt.setString(2, registro.getNombre());
            stmt.execute();
            System.out.println(stmt.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

           
       private void eliminarCargos() {

        try {
            PreparedStatement stmt;
            stmt = Conexion.getInstance().getConexion().prepareCall("{call sp_EliminarCargos(?)}");
            stmt.setInt(1, Integer.parseInt(txtId.getText()));
            stmt.execute();
            System.out.println(stmt.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    public boolean existeElementoSeleccionado() {

        if (tblCargos.getSelectionModel().getSelectedItem() == null) {
            return false;
        } else {
            return true;
        }
    }
     
    
    @FXML
    private void selecionarElemento(MouseEvent event) {
         if (existeElementoSeleccionado()) {
        txtId.setText(String.valueOf(((Cargos) tblCargos.getSelectionModel().getSelectedItem()).getId()));
        txtNombre.setText(((Cargos) tblCargos.getSelectionModel().getSelectedItem()).getNombre());
         }else {
            Alert vacio = new Alert(Alert.AlertType.ERROR);
            vacio.setTitle("Error");
            vacio.setContentText("Este campo esta vacio");
            vacio.setHeaderText(null);
            vacio.show();
        }
       }
    
     private void habitilarCampos() {
        txtId.setEditable(false);
        txtNombre.setEditable(true);

    }
  
    
    public void desabilitarControles() {
        txtId.setEditable(true);
        txtNombre.setEditable(false);
    }

    public void limpiarCampos() {
        txtId.clear();
        txtNombre.clear();
    }
    
    

    @FXML
    private void nuevo(ActionEvent event) {
        
         System.out.println("Operaciones" + operacion);
        
                switch (operacion) {
            case NINGUNO:
                habitilarCampos();
                btnNuevo.setText("Guardar");
                btnEliminar.setText("Cancelar");
                imgNuevo.setImage(new Image(PACK_IMAGEN + "Guardar.png"));
                imgEliminar.setImage(new Image(PACK_IMAGEN + "Cancelar.png"));
                btnEditar.setDisable(true);
                btnReporte.setDisable(true);
                operacion = Operaciones.GUARDAR;
                break;
              
            case GUARDAR:
                if (txtNombre.getText().isEmpty()) {             
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Necesita agregar la Informacion");
                    alert.show();
                } else {
                    btnNuevo.setDisable(false);
                    agregarCargos();
                    CargarDatos();
                    limpiarCampos();
                    btnNuevo.setText("Nuevo");
                    btnEliminar.setText("Eliminar");
                    imgNuevo.setImage(new Image(PACK_IMAGEN + "Agregar.png"));
                    imgEliminar.setImage(new Image(PACK_IMAGEN + "Eliminar.png"));
                    btnEditar.setDisable(false);
                    btnReporte.setDisable(false);
                    operacion = Operaciones.NINGUNO;
                }
                break;                
        }
        System.out.println("Operación: " + operacion);
        
    }

    @FXML
    private void editar(ActionEvent event) {
        System.out.println("Operacion" + operacion);
       
       switch (operacion){
           case NINGUNO:
                habitilarCampos();
                btnEditar.setText("Actualizar");
                btnReporte.setText("Cancelar");
                 imgEditar.setImage(new Image(PACK_IMAGEN + "Guardar.png"));
                 imgReporte.setImage(new Image(PACK_IMAGEN + "Cancelar.png"));
                btnNuevo.setDisable(true);
                btnEliminar.setDisable(true);
                operacion = Operaciones.ACTUALIZAR;
                break;
            case ACTUALIZAR:
                
                if (txtId.getText().isEmpty()) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Necesita seleccionar un registro para continuar");
                    alert.show();
                } else {
                editarCargos();
                limpiarCampos();
                desabilitarControles();
                CargarDatos();
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                btnEditar.setText("Editar");
                btnReporte.setText("Reporte");
                imgEditar.setImage(new Image(PACK_IMAGEN + "Editar.png"));
                imgReporte.setImage(new Image(PACK_IMAGEN + "Reporte.png"));
                operacion = Operaciones.NINGUNO;
                break;
                }
                 System.out.println("Operación: " + operacion);
        }
            
        
    }

    @FXML
    private void eliminar(ActionEvent event) {
        System.out.println("Operación: " + operacion);
        
        switch (operacion) {
            
            case GUARDAR:
                btnNuevo.setText("Nuevo");
                btnEliminar.setText("Eliminar");
                 imgNuevo.setImage(new Image(PACK_IMAGEN + "Agregar.png"));
                 imgEliminar.setImage(new Image(PACK_IMAGEN + "Eliminar.png"));
                btnEditar.setDisable(false);
                btnReporte.setDisable(false);
                limpiarCampos();
                desabilitarControles();
                operacion = Operaciones.NINGUNO;
                break;
                
            case NINGUNO: //Eliminar
                if (txtId.getText().isEmpty()) {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Debe seleccionar el registro a eliminar");
                    alert.show();
                } else {
                     Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("¿Está seguro que desea eliminar este registro?");
                    
                    Optional<ButtonType> respuesta = alert.showAndWait();
                    
                    if (respuesta.get() == ButtonType.OK) {
                        eliminarCargos();
                        limpiarCampos();
                        CargarDatos();                  
                }                
                break; 
        }
        System.out.println("Operación: " + operacion);            
   }
    
    
    }

    @FXML
    private void reporte(ActionEvent event) {
        System.out.println("Operación: " + operacion);
        switch (operacion) {
            case ACTUALIZAR:
                btnEditar.setText("Editar");
                btnReporte.setText("Reportar");
                 imgEditar.setImage(new Image(PACK_IMAGEN + "Editar.png"));
                 imgReporte.setImage(new Image(PACK_IMAGEN + "Reporte.png"));
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                limpiarCampos();
                desabilitarControles();
                operacion = Operaciones.NINGUNO;
                break;
        }
        
        
        
    }

}
