/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.miguelmassella.controller;

import java.math.BigDecimal;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import org.miguelmassella.bean.Proveedores;
import org.miguelmassella.db.Conexion;
import org.miguelmassella.system.Principal;

/**
 *
 * @author migue
 * @date 15/07/2021
 * @time 18:41:13
 * @code IN5BV
*/
public class ProveedoresController implements Initializable{

    private Principal escenarioPrincipal;
    
     private ObservableList<Proveedores> listaProveedores;
     
     private enum Operaciones{NUEVO, GUARDAR, EDITAR, ELIMINAR, 
                                ACTUALIZAR, CANCELAR, NINGUNO};
    
    private Operaciones operacion = Operaciones.NINGUNO;
   
    private final String PACK_IMAGEN = "/org/miguelmassella/resource/image/" ; 
    
    
    
    @FXML
    private Button btnNuevo;
    @FXML
    private ImageView imgNuevo;
    @FXML
    private Button btnEliminar;
    @FXML
    private ImageView imgEliminar;
    @FXML
    private Button btnEditar;
    @FXML
    private ImageView imgEditar;
    @FXML
    private Button btnReporte;
    @FXML
    private ImageView imgReporte;
    @FXML
    private TableView tblProveedores;
    @FXML
    private TableColumn colId;
    @FXML
    private TableColumn colNit;
    @FXML
    private TableColumn colServicioPrestado;
    @FXML
    private TableColumn colTelefono;
    @FXML
    private TableColumn colDireccion;
    @FXML
    private TableColumn colSaldoFavor;
    @FXML
    private TableColumn colSaldoContra;
    @FXML
    private TextField txtId;
    @FXML
    private TextField txtNit;
    @FXML
    private TextField txtTelefono;
    @FXML
    private TextField txtSaldoFavor;
    @FXML
    private TextField txtDireccion;
    @FXML
    private TextField txtServicioPrestado;
    @FXML
    private TextField txtSaldoContra;
    @FXML
    private TextField txtSaldoLiquido;

    BigDecimal saldoFavor;
    BigDecimal saldoContra;
    BigDecimal saldoLiquido;
     
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cargarDatos();
    }
    
    
    
    @FXML
    private void mostrarPrincipal(MouseEvent event) {
        escenarioPrincipal.mostrarMenuPrincipal();
    }

    public Principal getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }

    
    public void cargarDatos() {
        tblProveedores.setItems(getProveedores());
        colId.setCellValueFactory(new PropertyValueFactory<Proveedores, Integer>("id"));
        colNit.setCellValueFactory(new PropertyValueFactory<Proveedores, String>("nit"));
        colServicioPrestado.setCellValueFactory(new PropertyValueFactory<Proveedores, String>("servicioPrestado"));
        colSaldoFavor.setCellValueFactory(new PropertyValueFactory<Proveedores, BigDecimal>("SaldoFavor"));
        colSaldoContra.setCellValueFactory(new PropertyValueFactory<Proveedores, BigDecimal>("SaldoContra"));
        colTelefono.setCellValueFactory(new PropertyValueFactory<Proveedores, String>("telefono"));
        colDireccion.setCellValueFactory(new PropertyValueFactory<Proveedores, String>("direccion"));
    }

    
     public ObservableList<Proveedores> getProveedores() {
        ArrayList<Proveedores> lista = new ArrayList<>();
            try {
                PreparedStatement pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarProveedores()}");
                ResultSet rs = pstmt.executeQuery();

                while (rs.next()) {
                    lista.add(new Proveedores(
                            rs.getInt("id"),
                            rs.getString("nit"),
                            rs.getString("servicioPrestado"),
                            rs.getString("telefono"),
                            rs.getString("direccion"),
                            rs.getBigDecimal("saldoFavor"),
                            rs.getBigDecimal("saldoContra"))
                    );
                }

            rs.close();
            pstmt.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        listaProveedores = FXCollections.observableArrayList(lista);
        return listaProveedores;
    }
     
       public boolean validarTelefono(String numero) {
        Pattern pattern = Pattern.compile("^[0-9]{8}$");
        Matcher matcher = pattern.matcher(numero);
        return matcher.matches();
             }
   
    @FXML
    private void mostrarCuentasPagar(ActionEvent event) {
        escenarioPrincipal.mostraCuentasPagar();
    }

    
    
    @FXML
    private void seleccionarElemento(MouseEvent event) {
       
                txtId.setText(String.valueOf(((Proveedores) tblProveedores.getSelectionModel().getSelectedItem()).getId()));
                txtId.setText(String.valueOf(((Proveedores) tblProveedores.getSelectionModel().getSelectedItem()).getId()));
                txtNit.setText(String.valueOf(((Proveedores) tblProveedores.getSelectionModel().getSelectedItem()).getNit()));
                txtServicioPrestado.setText(String.valueOf(((Proveedores) tblProveedores.getSelectionModel().getSelectedItem()).getServicioPrestado()));
                txtTelefono.setText(String.valueOf(((Proveedores) tblProveedores.getSelectionModel().getSelectedItem()).getTelefono()));
                txtDireccion.setText(String.valueOf(((Proveedores) tblProveedores.getSelectionModel().getSelectedItem()).getDireccion()));
                txtSaldoFavor.setText(String.valueOf(((Proveedores) tblProveedores.getSelectionModel().getSelectedItem()).getSaldoFavor()));
                saldoFavor = ((Proveedores) tblProveedores.getSelectionModel().getSelectedItem()).getSaldoFavor();
                txtSaldoContra.setText(String.valueOf(((Proveedores) tblProveedores.getSelectionModel().getSelectedItem()).getSaldoContra()));
                saldoContra = ((Proveedores) tblProveedores.getSelectionModel().getSelectedItem()).getSaldoContra();
                mostrarSaldoLiquido();           
    }

    
     public void agregarProveedores() {

        Proveedores proveedores = new Proveedores();
        proveedores.setNit(txtNit.getText());
        proveedores.setServicioPrestado(txtServicioPrestado.getText());
        proveedores.setTelefono(txtTelefono.getText());
        proveedores.setDireccion(txtDireccion.getText());

        BigDecimal d = new BigDecimal(txtSaldoFavor.getText());
        proveedores.setSaldoFavor(d);
        BigDecimal c = new BigDecimal(txtSaldoContra.getText());
        proveedores.setSaldoContra(c);

        PreparedStatement pstmt = null;

        try {
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_AgregarProveedores(?, ?, ?, ?, ?, ?)}");
            pstmt.setString(1, proveedores.getNit());
            pstmt.setString(2, proveedores.getServicioPrestado());
            pstmt.setString(3, proveedores.getTelefono());
            pstmt.setString(4, proveedores.getDireccion());
            pstmt.setBigDecimal(5, proveedores.getSaldoFavor());
            pstmt.setBigDecimal(6, proveedores.getSaldoContra());
            System.out.println(pstmt);
            pstmt.execute();
            
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    
     
     
      public void editarProveedores() {

        Proveedores proveedores = new Proveedores();
        proveedores.setId(Integer.parseInt(txtId.getText()));
        proveedores.setNit(txtNit.getText());
        proveedores.setServicioPrestado(txtServicioPrestado.getText());
        proveedores.setTelefono(txtTelefono.getText());
        proveedores.setDireccion(txtDireccion.getText());
        BigDecimal d = new BigDecimal(txtSaldoFavor.getText());
        proveedores.setSaldoFavor(d);
        BigDecimal c = new BigDecimal(txtSaldoContra.getText());
        proveedores.setSaldoContra(c);

        PreparedStatement pstmt = null;

        try {
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_EditarProveedores(?, ?, ?, ?, ?, ?, ?)}");
            
            pstmt.setInt(1, proveedores.getId());
            pstmt.setString(2, proveedores.getNit());
            pstmt.setString(3, proveedores.getServicioPrestado());
            pstmt.setString(4, proveedores.getTelefono());
            pstmt.setString(5, proveedores.getDireccion());
            pstmt.setBigDecimal(6, proveedores.getSaldoFavor());
            pstmt.setBigDecimal(7, proveedores.getSaldoContra());
            System.out.println(pstmt);
            pstmt.execute();

        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar agregar proveedor");
            e.printStackTrace();
        } finally {
            try {
                pstmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

      private void eliminarProveedores() {
            try {
                PreparedStatement stmt;
                stmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_EliminarProveedores(?)}");

                stmt.setInt(1, ((Proveedores) tblProveedores.getSelectionModel().getSelectedItem()).getId());
                stmt.execute();
                System.out.println(stmt.toString());
                } catch (Exception e) {
                e.printStackTrace();

            }
    }
      
 
    private void mostrarSaldoLiquido() {

        txtSaldoLiquido.setText(String.valueOf(saldoFavor.subtract(saldoContra)));

    }

    
     public boolean existeElementoSeleccionado() {

            if (tblProveedores.getSelectionModel().getSelectedItem() == null) {
                return false;
            } else {
                return true;
                 }
            }    
    
    
     public void activarControles() {
        txtId.setEditable(false);
        txtId.setDisable(false);
        txtNit.setDisable(false);
        txtServicioPrestado.setDisable(false);
        txtTelefono.setDisable(false);
        txtDireccion.setDisable(false);
        txtSaldoFavor.setDisable(false);
        txtSaldoContra.setDisable(false);
        txtSaldoLiquido.setEditable(false);
    }

     
    public void desactivarControles() {
        txtId.setEditable(false);
        txtId.setDisable(false);
        txtNit.setDisable(true);
        txtServicioPrestado.setDisable(true);
        txtTelefono.setDisable(true);
        txtDireccion.setDisable(true);
        txtSaldoFavor.setDisable(true);
        txtSaldoContra.setDisable(true);
        txtSaldoLiquido.setDisable(true);
    }

    public void limpiarControles() {
        txtId.clear();
        txtNit.clear();
        txtServicioPrestado.clear();
        txtTelefono.clear();
        txtDireccion.clear();
        txtSaldoFavor.clear();
        txtSaldoContra.clear();
        txtSaldoLiquido.clear();
    }
    
   
    @FXML
    private void nuevo(ActionEvent event) {
        
         switch (operacion) {
            case NINGUNO:
                activarControles();
                limpiarControles();

                btnNuevo.setText("Guardar");

                btnEditar.setDisable(true);

                btnEliminar.setText("Cancelar");

                imgNuevo.setImage(new Image(PACK_IMAGEN + "Guardar.png"));
                imgEliminar.setImage(new Image(PACK_IMAGEN + "Cancelar.png"));

                btnReporte.setDisable(true);

                operacion = Operaciones.GUARDAR;
                break;

            case GUARDAR:
          
                    if (txtNit.getText().length() != 0
                        && txtServicioPrestado.getText().length() != 0
                        && txtDireccion.getText().length() != 0
                        && txtSaldoFavor.getText().length() != 0
                        && txtSaldoContra.getText().length() != 0) {
                    if (validarTelefono(txtTelefono.getText())) {                    
                        agregarProveedores();
                        cargarDatos();
                        desactivarControles();
                        limpiarControles();
                        btnNuevo.setText("Nuevo");
                        imgNuevo.setImage(new Image(PACK_IMAGEN + "Agregar.png"));

                        btnEliminar.setText("Eliminar");
                        imgEliminar.setImage(new Image(PACK_IMAGEN + "Eliminar.png"));

                        btnEditar.setDisable(false);
                        btnReporte.setDisable(false);

                        operacion = Operaciones.NINGUNO;
                        
                   
                        
                        } else {
                    Alert vacio = new Alert(Alert.AlertType.ERROR);
                    vacio.setTitle("Error");
                    vacio.setContentText("El numero que ingreso pasa de los 8 digitos o le falta");
                    vacio.setHeaderText(null);
                    vacio.show();
                }
                    } else {
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("KINAL MALL");
                        alert.setHeaderText(null);
                        alert.setContentText("No puede dejar campos vacios, verifique la informacion");
                        alert.show();
                    }
                break;
        }
    
        
        
        
    }

    @FXML
    private void eliminar(ActionEvent event) {
         switch (operacion) {
            case GUARDAR:

                btnNuevo.setText("Nuevo");

                btnEliminar.setText("Eliminar");

                imgNuevo.setImage(new Image(PACK_IMAGEN + "Agregar.png"));
                imgEliminar.setImage(new Image(PACK_IMAGEN + "Eliminar.png"));

                btnEditar.setDisable(false);
                btnReporte.setDisable(false);

                limpiarControles();
                desactivarControles();

                operacion = Operaciones.NINGUNO;
                break;
            case NINGUNO: // Eliminación
                if (existeElementoSeleccionado()) {

                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("¿Seguro que desea eliminar esta informacion?");

                    Optional<ButtonType> respuesta = alert.showAndWait();

                    if (respuesta.get() == ButtonType.OK) {
                        eliminarProveedores();
                        limpiarControles();
                        cargarDatos();
                    }

                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Debe seleccionar un registro para realizar esta accion");
                    alert.show();
                }

                break;
        }
        
        
        
        
        
        
        
    }

    @FXML
    private void editar(ActionEvent event) {
            
          switch (operacion) {
            case NINGUNO:
                if (existeElementoSeleccionado()) {
                    activarControles();

                    btnEditar.setText("Actualizar");
                    btnReporte.setText("Cancelar");
                    imgEditar.setImage(new Image(PACK_IMAGEN + "Guardar.png"));
                    imgReporte.setImage(new Image(PACK_IMAGEN + "Cancelar.png"));

                    btnNuevo.setDisable(true);
                    btnEliminar.setDisable(true);

                    operacion = Operaciones.ACTUALIZAR;

                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Debe seleccionar un registro para realizar esta accion");
                    alert.show();
                }

                break;

            case ACTUALIZAR:
                    if (validarTelefono(txtTelefono.getText())) {

                    if (txtNit.getText().length() != 0
                        && txtServicioPrestado.getText().length() != 0
                        && txtDireccion.getText().length() != 0
                        && txtSaldoFavor.getText().length() != 0
                        && txtSaldoContra.getText().length() != 0) {                  
                        
                        editarProveedores();    
                        limpiarControles();
                        desactivarControles();
                        cargarDatos();
                        btnNuevo.setDisable(false);
                        btnEliminar.setDisable(false);

                        btnEditar.setText("Editar");

                        btnReporte.setText("Reporte");
                        imgReporte.setImage(new Image(PACK_IMAGEN + "Reporte.png"));
                        imgEditar.setImage(new Image(PACK_IMAGEN + "Editar.png"));

                        operacion = Operaciones.NINGUNO;
                    break;
                    
                    
                } else {
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("KINAL MALL");
                        alert.setHeaderText(null);
                        alert.setContentText("No puede dejar campos vacios, verifique la informacion");
                        alert.show();
                    }
                } else {
                    Alert vacio = new Alert(Alert.AlertType.ERROR);
                    vacio.setTitle("Error");
                    vacio.setContentText("El numero que ingreso pasa de los 8 digitos o le falta");
                    vacio.setHeaderText(null);
                    vacio.show();
                }

        }
    
    
    
    
    }

    @FXML
    private void reporte(ActionEvent event) {
        switch (operacion) {
            case ACTUALIZAR:
                limpiarControles();
                desactivarControles();
                //cargarDatos();
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);

                btnEditar.setText("Editar");
                btnReporte.setText("Reporte");

                imgReporte.setImage(new Image(PACK_IMAGEN + "Reporte.png"));
                imgEditar.setImage(new Image(PACK_IMAGEN + "Editar.png"));

                operacion = Operaciones.NINGUNO;
                break;
        }
        
        
    }

   

    
    
}
