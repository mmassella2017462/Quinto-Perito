/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.miguelmassella.db;
import java.sql.Connection;
import java.sql.DriverManager; 
import java.sql.SQLException;





/**
 *
 * @author migue
 * @date 27/05/2021
 * @time 16:09:13
 * @code IN5BV
*/
public class Conexion {
    private Connection conexion;
    private final String URL;
    private static Conexion instancia;
    private final String BD;
    private final String HOST;
    private final String PUERTO;
    private final String USER;
    private final String PASS;
    
    
private Conexion(){
    
    HOST = "localhost";
    PUERTO =  "3306";
    BD = "IN5BV_KinalMall";
            //"in5bv_kinalmall_miguelmassella";
    USER = "root";
    PASS = "admin";
    
    
   
    URL= "jdbc:mysql://"+HOST+ ":"+ PUERTO + "/"+ BD +"?allowPublicKeyRetrieval=true&serverTimezone=UTC&useSSL=false";
    
    try{
     Class.forName("com.mysql.jdbc.Driver").newInstance();
     conexion = DriverManager.getConnection(URL,USER, PASS);
         System.out.println("Conexion Exitosa!");
         }catch(ClassNotFoundException e){
             System.out.println("No se encuentra ninguba defnicion para la clase");  
             e.printStackTrace();
         } catch(InstantiationException e){
             System.out.println("No se puede crear una instancia del objeto");
             e.printStackTrace();
         } catch(IllegalAccessException e){
             System.out.println("No se tiene permitido el acceso al paquete");
             e.printStackTrace();
         } catch (SQLException e){
              System.out.println("Se produjo un error");
             e.printStackTrace();
         }
     }


      public Connection getConexion() {
        return conexion;
    }

      public static Conexion getInstance(){
         if (instancia == null){ 
             instancia = new Conexion();
         }
         return instancia;
      }

 
}
