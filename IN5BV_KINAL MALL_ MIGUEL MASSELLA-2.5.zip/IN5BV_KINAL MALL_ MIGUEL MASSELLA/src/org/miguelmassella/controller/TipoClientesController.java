/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.miguelmassella.controller;

import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javax.swing.JOptionPane;
import org.miguelmassella.bean.TipoCliente;
import org.miguelmassella.db.Conexion;
import org.miguelmassella.system.Principal;

/**
 *
 * @author migue
 * @date 24/06/2021
 * @time 13:46:30
 * @code IN5BV
*/
public class TipoClientesController implements Initializable{
    
    private ObservableList<TipoCliente> listadoClientes;
    
    private Principal escenarioPrincipal;
    
    private enum Operaciones{NUEVO, GUARDAR, EDITAR, ELIMINAR, 
                                ACTUALIZAR, CANCELAR, NINGUNO};
    
    private Operaciones operacion = Operaciones.NINGUNO;
    
    @FXML
    private TextField txtId;
    @FXML
    private TextField txtDescripcion;
    @FXML
    private TableView tblTipoClientes;
    @FXML
    private TableColumn colId;
    @FXML
    private TableColumn colDescripcion;
    @FXML
    private Button btnNuevo;
    @FXML
    private Button btnEditar;
    @FXML
    private Button btnEliminar;
    @FXML
    private Button btnReporte;

   
    public Principal getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }


      @Override
    public void initialize(URL url, ResourceBundle rb) {
       CargarDatos();
    }
    

    
    @FXML
    private void MostrarMenuPrincpal(MouseEvent event) {
        escenarioPrincipal.mostrarAdministracion();
    }

 
      public ObservableList<TipoCliente> getTipoCliente(){
        
        ArrayList<TipoCliente> listado = new ArrayList<TipoCliente>();
      
        try {   
            //CallableStatement stmt;
            PreparedStatement stmt;
            stmt= Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarTipoCliente()}");
            ResultSet resultado = stmt.executeQuery();
            
            while (resultado.next()){
                listado.add(new TipoCliente(
                                resultado.getInt("id"),
                                resultado.getString("descripcion")
                              
                )   );
            }
            
           // listado.forEach(elemento -> {
               // System.out.println(elemento);});
  
            resultado.close();
            stmt.close();
        
        }catch( SQLException e){
            e.printStackTrace();
        } 
       listadoClientes = FXCollections.observableArrayList(listado);      
        return listadoClientes;             
    }
    
      
      
       private void habitilarCampos() {
        txtId.setEditable(false);
        txtDescripcion.setEditable(true);
        
    }
  
    
    public void desabilitarControles() {
        txtId.setEditable(true);
        txtDescripcion.setEditable(false);
        btnNuevo.setDisable(false);
    }

    public void limpiarCampos() {
        txtId.clear();
        txtDescripcion.clear();
    }         
    
    @FXML
    public void selecionarElemento() {
        txtId.setText(String.valueOf(((TipoCliente) tblTipoClientes.getSelectionModel().getSelectedItem()).getId()));
        txtDescripcion.setText(((TipoCliente) tblTipoClientes.getSelectionModel().getSelectedItem()).getDescripcion());
    }
    
     public void agregarTipoCliente() {

       TipoCliente registro = new TipoCliente();
        registro.setDescripcion(txtDescripcion.getText());

        try {
            PreparedStatement stmt;
            stmt = Conexion.getInstance().getConexion().prepareCall("{call sp_AgregarTipoCliente(?)}");
            stmt.setString(1, registro.getDescripcion());
            stmt.execute();
        } catch (Exception e) {
            e.printStackTrace(); }
    }

       private void editarTipoCliente() {

        TipoCliente registro = new TipoCliente();

        registro.setId(Integer.parseInt(txtId.getText()));
        registro.setDescripcion(txtDescripcion.getText());

        try {
            PreparedStatement stmt;
            stmt = Conexion.getInstance().getConexion().prepareCall("{call sp_EditarTipoCliente(?, ?)}");
            stmt.setInt(1, registro.getId());
            stmt.setString(2, registro.getDescripcion());
            stmt.execute();
            System.out.println(stmt.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

           
       private void eliminarTipoClientes() {

        try {
            PreparedStatement stmt;
            stmt = Conexion.getInstance().getConexion().prepareCall("{call sp_EliminarTipoCliente(?)}");
            stmt.setInt(1, Integer.parseInt(txtId.getText()));
            stmt.execute();
            System.out.println(stmt.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }    
    
      public void CargarDatos(){
       
       tblTipoClientes.setItems(getTipoCliente());
       colId.setCellValueFactory( new PropertyValueFactory<TipoCliente, Integer>("id"));
       colDescripcion.setCellValueFactory(new PropertyValueFactory<TipoCliente, String>("Descripcion"));
      }
    
    
    
    @FXML
    private void nuevo(ActionEvent event) {
          System.out.println("Operaciones" + operacion);
        
                switch (operacion) {
            case NINGUNO:
                habitilarCampos();
                btnNuevo.setText("Guardar");
                btnEliminar.setText("Cancelar");
                btnEditar.setDisable(true);
                btnReporte.setDisable(true);
                operacion = Operaciones.GUARDAR;
                break;
              
            case GUARDAR:
                if (txtDescripcion.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Debes Ingresar Datos");
                } else {
                    btnNuevo.setDisable(false);
                    agregarTipoCliente();
                    CargarDatos();
                    limpiarCampos();
                    btnNuevo.setText("Nuevo");
                    btnEliminar.setText("Eliminar");
                    btnEditar.setDisable(false);
                    btnReporte.setDisable(false);
                    operacion = Operaciones.NINGUNO;
                }
                break;                
        }
        System.out.println("Operación: " + operacion);
        
        
    }

    @FXML
    private void editar(ActionEvent event) {
        
         System.out.println("Operacion" + operacion);
       
       switch (operacion){
           case NINGUNO:
                habitilarCampos();
                btnEditar.setText("Actualizar");
                btnReporte.setText("Cancelar");
                btnNuevo.setDisable(true);
                btnEliminar.setDisable(true);
                operacion = Operaciones.ACTUALIZAR;
                break;
            case ACTUALIZAR:
                    if (txtId.getText().isEmpty()) {
                    JOptionPane.showConfirmDialog(null, "Debe seleccionar un elemento para Editarlo");
                } else {
                editarTipoCliente();
                limpiarCampos();
                desabilitarControles();
                CargarDatos();
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                btnEditar.setText("Editar");
                btnReporte.setText("Reporte");
                operacion = Operaciones.NINGUNO;
                break;
                }
                 System.out.println("Operación: " + operacion);
        }
        
        
    }

    
    
    @FXML
    private void eliminar(ActionEvent event) {
        
        System.out.println("Operación: " + operacion);
        
        switch (operacion) {
            
            case GUARDAR:
                btnNuevo.setText("Nuevo");
                btnEliminar.setText("Eliminar");
                btnEditar.setDisable(false);
                btnReporte.setDisable(false);
                limpiarCampos();
                desabilitarControles();
                operacion = Operaciones.NINGUNO;
                break;
                
            case NINGUNO: //Eliminar
                if (txtId.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No se pude realizar esta accion");
                } else {
                    
                    int opcion = JOptionPane.showConfirmDialog(null, "¿Estas seguro de eliminar el Registro?");
                     
                    if (JOptionPane.YES_OPTION == opcion) {
                        eliminarTipoClientes();
                        limpiarCampos();
                        CargarDatos();                  
                }                
                break; 
        }
        System.out.println("Operación: " + operacion);            
   }
        
        
    }

    
    
    @FXML
    private void reporte(ActionEvent event) {
        System.out.println("Operación: " + operacion);
        switch (operacion) {
            case ACTUALIZAR:
                btnEditar.setText("Editar");
                btnReporte.setText("Reportar");
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                limpiarCampos();
                desabilitarControles();
                operacion = Operaciones.NINGUNO;
                break;
            case NINGUNO: //Reportar
                btnReporte.setText("Reportar");
                btnNuevo.setDisable(false);
                btnEditar.setDisable(false);
                btnEliminar.setDisable(false);
                limpiarCampos();
                desabilitarControles();
                CargarDatos();
                operacion = Operaciones.NINGUNO;
                break;

        }
        System.out.println("Operación: " + operacion);
    }

    
    
    
    
    
}
