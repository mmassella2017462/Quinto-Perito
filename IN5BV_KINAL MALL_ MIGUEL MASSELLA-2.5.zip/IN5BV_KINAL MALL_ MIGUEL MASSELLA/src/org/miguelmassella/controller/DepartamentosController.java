/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.miguelmassella.controller;

import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javax.swing.JOptionPane;
import org.miguelmassella.bean.Departamentos;
import org.miguelmassella.db.Conexion;
import org.miguelmassella.system.Principal;

/**
 *
 * @author migue
 * @date 18/06/2021
 * @time 17:49:18
 * @code IN5BV
*/
public class DepartamentosController  implements Initializable {

    private ObservableList<Departamentos> listadoDepas;
    
    private enum Operaciones{NUEVO, GUARDAR, EDITAR, ELIMINAR, 
                                ACTUALIZAR, CANCELAR, NINGUNO};
    
    private Operaciones operacion = Operaciones.NINGUNO;
    
    private Principal escenarioPrincipal;
    
    @FXML
    private TextField txtId;
    @FXML
    private TableColumn colId;
    @FXML
    private Button btnNuevo;
    @FXML
    private Button btnEditar;
    @FXML
    private Button btnEliminar;
    @FXML
    private Button btnReporte;
    @FXML
    private TableView tblDepartamentos;
    @FXML
    private TableColumn colNombre;
    @FXML
    private TextField txtNombre;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        CargarDatos();
    }
    
      public Principal getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }

    @FXML
    private void MostrarPrincipal(MouseEvent event) {
        escenarioPrincipal.mostrarAdministracion();
    }

    
    public ObservableList<Departamentos> getDepartamentos(){
        
        ArrayList<Departamentos> listado = new ArrayList<Departamentos>();
        
        
        try {   
            //CallableStatement stmt;
            PreparedStatement stmt;
            stmt= Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarDepartamentos()}");
            ResultSet resultado = stmt.executeQuery();
            
            while (resultado.next()){
                listado.add(new Departamentos(
                                resultado.getInt("id"),
                                resultado.getString("nombre") 
                                
                )   );
            }
            
           // listado.forEach(elemento -> {
               // System.out.println(elemento);});
              
            resultado.close();
            stmt.close();
            
            
        }catch( SQLException e){
            e.printStackTrace();
        } 
       listadoDepas = FXCollections.observableArrayList(listado);
       
        return listadoDepas;
                
    }
    
    
     private void habitilarCampos() {
        txtId.setEditable(false);
        txtNombre.setEditable(true);
        
    }
  
    
    public void desabilitarControles() {
        txtId.setEditable(true);
        txtNombre.setEditable(false);
        btnNuevo.setDisable(false);
    }

    public void limpiarCampos() {
        txtId.clear();
        txtNombre.clear();
    }         
    
    @FXML
    public void selecionarElemento() {
        txtId.setText(String.valueOf(((Departamentos) tblDepartamentos.getSelectionModel().getSelectedItem()).getId()));
        txtNombre.setText(((Departamentos) tblDepartamentos.getSelectionModel().getSelectedItem()).getNombre());
    }
    
     public void agregarDepartamentos() {

        Departamentos registro = new Departamentos();
        registro.setNombre(txtNombre.getText());

        try {
            PreparedStatement stmt;
            stmt = Conexion.getInstance().getConexion().prepareCall("{call sp_AgregarDepartamentos(?)}");
            stmt.setString(1, registro.getNombre());
            stmt.execute();
        } catch (Exception e) {
            e.printStackTrace(); }
    }

       private void editarDepartamentos() {

        Departamentos registro = new Departamentos();

        registro.setId(Integer.parseInt(txtId.getText()));
        registro.setNombre(txtNombre.getText());

        try {
            PreparedStatement stmt;
            stmt = Conexion.getInstance().getConexion().prepareCall("{call sp_EditarDepartamentos(?, ?)}");
            stmt.setInt(1, registro.getId());
            stmt.setString(2, registro.getNombre());
            stmt.execute();
            System.out.println(stmt.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

           
       private void eliminarDepartamentos() {

        try {
            PreparedStatement stmt;
            stmt = Conexion.getInstance().getConexion().prepareCall("{call sp_EliminarDepartamentos(?)}");
            stmt.setInt(1, Integer.parseInt(txtId.getText()));
            stmt.execute();
            System.out.println(stmt.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
     public void CargarDatos(){
       
       tblDepartamentos.setItems(getDepartamentos());
       colId.setCellValueFactory( new PropertyValueFactory<Departamentos, Integer>("id"));
       colNombre.setCellValueFactory(new PropertyValueFactory<Departamentos, String>("nombre"));
    }
    
    
    
    
    
    
    

    @FXML
    private void nuevo(ActionEvent event) {
        System.out.println("Operaciones" + operacion);
        
                switch (operacion) {
            case NINGUNO:
                habitilarCampos();
                btnNuevo.setText("Guardar");
                btnEliminar.setText("Cancelar");
                btnEditar.setDisable(true);
                btnReporte.setDisable(true);
                operacion = Operaciones.GUARDAR;
                break;
              
            case GUARDAR:
                if (txtNombre.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Debes Ingresar Datos");
                } else {
                    btnNuevo.setDisable(false);
                    agregarDepartamentos();
                    CargarDatos();
                    limpiarCampos();
                    btnNuevo.setText("Nuevo");
                    btnEliminar.setText("Eliminar");
                    btnEditar.setDisable(false);
                    btnReporte.setDisable(false);
                    operacion = Operaciones.NINGUNO;
                }
                break;                
        }
        System.out.println("Operación: " + operacion);
    }

    
    @FXML
    private void editar(ActionEvent event) {
        System.out.println("Operacion" + operacion);
       
       switch (operacion){
           case NINGUNO:
                habitilarCampos();
                btnEditar.setText("Actualizar");
                btnReporte.setText("Cancelar");
                btnNuevo.setDisable(true);
                btnEliminar.setDisable(true);
                operacion = Operaciones.ACTUALIZAR;
                break;
            case ACTUALIZAR:
                
                if (txtId.getText().isEmpty()) {
                    JOptionPane.showConfirmDialog(null, "Debe seleccionar un elemento para Editarlo");
                } else {
                editarDepartamentos();
                limpiarCampos();
                desabilitarControles();
                CargarDatos();
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                btnEditar.setText("Editar");
                btnReporte.setText("Reporte");
                operacion = Operaciones.NINGUNO;
                break;
                }
                 System.out.println("Operación: " + operacion);
        }
        
        
        
    }

    
    @FXML
    private void eliminar(ActionEvent event) {
         System.out.println("Operación: " + operacion);
        
        switch (operacion) {
            
            case GUARDAR:
                btnNuevo.setText("Nuevo");
                btnEliminar.setText("Eliminar");
                btnEditar.setDisable(false);
                btnReporte.setDisable(false);
                limpiarCampos();
                desabilitarControles();
                operacion = Operaciones.NINGUNO;
                break;
                
            case NINGUNO: //Eliminar
                if (txtId.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No se pude realizar esta accion");
                } else {
                    
                    int opcion = JOptionPane.showConfirmDialog(null, "¿Estas seguro de eliminar el Registro?");
                     
                    if (JOptionPane.YES_OPTION == opcion) {
                        eliminarDepartamentos();
                        limpiarCampos();
                        CargarDatos();                  
                }                
                break; 
        }
        System.out.println("Operación: " + operacion);            
   }
        
        
    }

    
    @FXML
    private void reporte(ActionEvent event) {
         System.out.println("Operación: " + operacion);
        switch (operacion) {
            case ACTUALIZAR:
                btnEditar.setText("Editar");
                btnReporte.setText("Reportar");
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                limpiarCampos();
                desabilitarControles();
                operacion = Operaciones.NINGUNO;
                break;
            case NINGUNO: //Reportar
                btnReporte.setText("Reportar");
                btnNuevo.setDisable(false);
                btnEditar.setDisable(false);
                btnEliminar.setDisable(false);
                limpiarCampos();
                desabilitarControles();
                CargarDatos();
                operacion = Operaciones.NINGUNO;
                break;

        }
        System.out.println("Operación: " + operacion);
    }
    
    
        
    }
 
    
    
    

