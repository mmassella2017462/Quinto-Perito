/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.miguelmassella.system;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.fxml.JavaFXBuilderFactory;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import org.miguelmassella.controller.AdministracionController;
import org.miguelmassella.controller.AutorController;
import org.miguelmassella.controller.CargosController;
import org.miguelmassella.controller.ClientesController;
import org.miguelmassella.controller.CuentasPorCobrarController;
import org.miguelmassella.controller.CuentasPorPagarController;
import org.miguelmassella.controller.DepartamentosController;
import org.miguelmassella.controller.EmpleadosController;
import org.miguelmassella.controller.HorariosController;
import org.miguelmassella.controller.LocalesController;
import org.miguelmassella.controller.MenuPrincipalController;
import org.miguelmassella.controller.ProveedoresController;
import org.miguelmassella.controller.TipoClientesController;






/**
 *
 * @author migue
 * @creator Miguel Antonio Massella Elias
 * @date 12/05/2021
 * @time 18:08:25
 * @code IN5BV
 */
public class Principal extends Application {
    
    private Stage escenarioPrincipal;
    private Scene escena;
    private final String PACKVIEW = "/org/miguelmassella/view/";
    private final String PACK_CSS = "/org/miguelmassella/resource/css/";
    
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        this.escenarioPrincipal = stage;
        escenarioPrincipal.getIcons().add(new Image("/org/miguelmassella/resource/image/Kinal Mall Logo.png"));
        mostrarMenuPrincipal();
    
    }

    public void mostrarMenuPrincipal(){
       try{ 
           MenuPrincipalController menuController = (MenuPrincipalController) cambiarEscena("MenuPrincipalView.fxml",800,449);
           menuController.setEscenarioPrincipal(this);
       } catch(Exception e) {
           System.out.println("Error al cargar Menu Principal");
           e.printStackTrace();
       }
        
    }
    
    public void mostrarAutor(){
      try{
          AutorController autorController =(AutorController) cambiarEscena("AutorView.fxml",490 ,270);
          autorController.setEscenarioPrincipal(this);
      }catch (Exception e){
          System.out.println("No se pudo mostrar Vista Autor");
          e.printStackTrace();
      
      }
        
        
    }
    
    
    public void mostrarAdministracion(){
        try{ 
            AdministracionController administracion = (AdministracionController) cambiarEscena("AdministracionView.fxml",800,449);
            administracion.setEscenarioPrincipal(this);
        }catch(Exception e){
             System.out.println("No se pudo cargar la Adminsitracion");
          e.printStackTrace();
        }
    }
    
    
    
     public void mostrarClientes(){
         try{
             ClientesController clientes = (ClientesController) cambiarEscena("ClientesView.fxml",1300,650);
             clientes.setEscenarioPrincipal(this);
         }catch(Exception e){
             System.out.println("No se pudo cargar la vista Clientes");
             e.printStackTrace();
         }
     }
    
    
     
      public void mostrarProveedores(){
        try{ 
            ProveedoresController provedor = (ProveedoresController) cambiarEscena("ProveedoresView.fxml",1000,600);
            provedor.setEscenarioPrincipal(this);
        }catch(Exception e){
             System.out.println("No se pudo cargar la vista de Proveedores");
          e.printStackTrace();
        }
    }
      
      
       public void mostrarEmpleados(){
        try{ 
            EmpleadosController Empleado = (EmpleadosController) cambiarEscena("EmpleadosView.fxml",1000,600);
            Empleado.setEscenarioPrincipal(this);
        }catch(Exception e){
             System.out.println("No se pudo cargar la vista de Proveedores");
          e.printStackTrace();
        }
    }
     
     
    
    
    
     public void mostrarDepartamentos() {
         try{
             DepartamentosController depas = (DepartamentosController) cambiarEscena("DepartamentosView.fxml",800,449);
             depas.setEscenarioPrincipal(this);
         } catch(Exception e){
             System.out.println("Fallo al Cargar Vista Departamentos");
             e.printStackTrace();
         }
    
    }

    
   
     public void MostrarTipoClientes(){
         try{
             TipoClientesController clientes = (TipoClientesController) cambiarEscena("TipoClientesView.fxml",800,449);
             clientes.setEscenarioPrincipal(this);
         }catch(Exception e){
             System.out.println("No se pudo cargar la vista Tipo Clientes");
             e.printStackTrace();
         }
     }
    
     
      public void mostrarLocales(){
        try{ 
            LocalesController local = (LocalesController) cambiarEscena("LocalesView.fxml",1000,600);
            local.setEscenarioPrincipal(this);
        }catch(Exception e){
             System.out.println("No se pudo cargar la vista de Locales");
          e.printStackTrace();
        }
    }
      
     
      
       public void mostrarCargos() {
         try{
             CargosController cargo = (CargosController) cambiarEscena("Cargos.fxml",800,449);
             cargo.setEscenarioPrincipal(this);
         } catch(Exception e){
             System.out.println("Fallo al Cargar Vista Cargos");
             e.printStackTrace();
         }
    
    }
     
      
      public void mostraCuentasCobrar(){
          try{ 
            CuentasPorCobrarController cobrar = (CuentasPorCobrarController) cambiarEscena("CuentasPorCobrarView.fxml",1000,600);
            cobrar.setEscenarioPrincipal(this);
        }catch(Exception e){
             System.out.println("No se pudo cargar la vista de Cuentas por Cobrar");
          e.printStackTrace();
        }
      
      }
    
       public void mostraCuentasPagar(){
          try{ 
            CuentasPorPagarController pagar = (CuentasPorPagarController) cambiarEscena("CuentasPorPagarView.fxml",1000,600);
            pagar.setEscenarioPrincipal(this);
        }catch(Exception e){
             System.out.println("No se pudo cargar la vista de Cuentas por Pagar");
          e.printStackTrace();
        }
      
      }
      
       
       public void mostrarHorarios(){
        try{ 
            HorariosController Horario = (HorariosController) cambiarEscena("HorariosView.fxml",1000,600);
            Horario.setEscenarioPrincipal(this);
        }catch(Exception e){
             System.out.println("No se pudo cargar la vista de Proveedores");
          e.printStackTrace();
        }
    }
       
      
    
    public Initializable cambiarEscena(String fxml, int ancho, int alto) throws IOException{
        Initializable resultado;
        
        FXMLLoader cargadorFXML = new FXMLLoader();
        cargadorFXML.setBuilderFactory(new JavaFXBuilderFactory());
        cargadorFXML.setLocation(Principal.class.getResource(PACKVIEW + fxml));
        InputStream archivo = Principal.class.getResourceAsStream(PACKVIEW + fxml);
        escena = new Scene((AnchorPane) cargadorFXML.load(archivo),ancho,alto);
        
        escena.getStylesheets().add(PACK_CSS + "EstiloKinalMall.css");
        
        this.escenarioPrincipal.setScene(escena);
        this.escenarioPrincipal.sizeToScene();
        this.escenarioPrincipal.setResizable(false);
        this.escenarioPrincipal.show();
        
                
        resultado = (Initializable)cargadorFXML.getController();
        
        return resultado;
    }

   
     public boolean validar(ArrayList<TextField>listaTextField,ArrayList<ComboBox> listaComboBox){
       boolean respuesta = true;
       
      for(ComboBox comboBox : listaComboBox)
          if(comboBox.getSelectionModel().getSelectedItem() == null)
              return false;
      
       for (TextField campoTexto : listaTextField){
           if (campoTexto.getText().trim().isEmpty()){
               return false;
           }
       }
        return respuesta;
    
    }
    
    
    
    
    
    
       
}
