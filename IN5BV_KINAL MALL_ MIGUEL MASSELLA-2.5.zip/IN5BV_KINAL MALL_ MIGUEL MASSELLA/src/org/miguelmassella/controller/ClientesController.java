/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.miguelmassella.controller;

import java.net.URL;
import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import org.miguelmassella.bean.Administracion;
import org.miguelmassella.bean.Clientes;
import org.miguelmassella.bean.Locales;
import org.miguelmassella.bean.TipoCliente;
import org.miguelmassella.db.Conexion;
import org.miguelmassella.system.Principal;

/**
 *
 * @author migue
 * @date 29/06/2021
 * @time 15:38:15
 * @code IN5BV
*/
public class ClientesController implements Initializable{
     
     private Principal escenarioPrincipal; 
     
     private final String PACK_IMAGEN = "/org/miguelmassella/resource/image/" ; 
   
     private enum Operaciones {
        GUARDAR, ELIMINAR, EDITAR, NUEVO, ACTUALIZAR, CANCELAR, NINGUNO, REPORTE}

    private Operaciones operacion = Operaciones.NINGUNO;

    private ObservableList<Clientes> listaClientes;
    private ObservableList<Administracion> listaAdministracion;
    private ObservableList<TipoCliente> listaTipoClientes;
    private ObservableList<Locales> listaLocales;
 
    @FXML
    private TextField txtId;
    @FXML
    private TextField txtEmail;
    @FXML
    private TextField txtApellidos;
    @FXML
    private TableView tblClientes;
    @FXML
    private TableColumn colId;
    @FXML
    private TableColumn colNombres;
    @FXML
    private TableColumn colApellidos;
    @FXML
    private TableColumn colTelefono;
    @FXML
    private TableColumn colDireccion;
    @FXML
    private TableColumn colEmail;
    @FXML
    private TableColumn colLocal;
    @FXML
    private TableColumn colAdministracion;
    @FXML
    private TableColumn colTipoCliente;
    @FXML
    private TextField txtNombre;
    @FXML
    private TextField txtTelefono;
    @FXML
    private TextField txtDireccion;
    @FXML
    private Button btnNuevo;
    @FXML
    private Button btnEditar;
    @FXML
    private Button btnEliminar;
    @FXML
    private Button btnReporte;
    @FXML
    private ComboBox cmbLocal;
    @FXML
    private ComboBox cmbTipoCliente;
    @FXML
    private ComboBox cmbAdministracion;
    @FXML
    private ImageView imgNuevo;
    @FXML
    private ImageView imgEliminar;
    @FXML
    private ImageView imgEditar;
    @FXML
    private ImageView imgReporte;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cargarDatos();
    }

    public Principal getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }

    @FXML
    private void MostrarPrincipal(MouseEvent event) {
        escenarioPrincipal.mostrarMenuPrincipal();
    }
    
    
      @FXML
    private void mostrarCuentasCobrar(ActionEvent event) {
        escenarioPrincipal.mostraCuentasCobrar();
    }
    
    public void cargarDatos() {
        tblClientes.setItems(getClientes());
        colId.setCellValueFactory(new PropertyValueFactory<Clientes, Integer>("id"));
        colNombres.setCellValueFactory(new PropertyValueFactory<Clientes, String>("nombres"));
        colApellidos.setCellValueFactory(new PropertyValueFactory<Clientes, String>("apellidos"));
        colTelefono.setCellValueFactory(new PropertyValueFactory<Clientes, String>("telefono"));
        colDireccion.setCellValueFactory(new PropertyValueFactory<Clientes, String>("direccion"));
        colEmail.setCellValueFactory(new PropertyValueFactory<Clientes, String>("email"));
        colTipoCliente.setCellValueFactory(new PropertyValueFactory<Clientes, Integer>("idTipoCliente"));
        colLocal.setCellValueFactory(new PropertyValueFactory<Clientes, Integer>("idAdministracion"));
        colAdministracion.setCellValueFactory(new PropertyValueFactory<Clientes, Integer>("idLocal"));

        cmbTipoCliente.setItems(getTipoCliente());
        cmbLocal.setItems(getLocales());
        cmbAdministracion.setItems(getAdministracion());
    }
    
    
    
    
    
     public ObservableList<Clientes> getClientes() {
        ArrayList<Clientes> lista = new ArrayList<Clientes>();

        try {
            PreparedStatement stmt;

            stmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarClientes()}");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                lista.add(new Clientes(
                        rs.getInt("id"),
                        rs.getString("nombres"),
                        rs.getString("apellidos"),
                        rs.getString("telefono"),
                        rs.getString("direccion"),
                        rs.getString("email"),
                        rs.getInt("idLocal"),
                        rs.getInt("idAdministracion"), 
                        rs.getInt("idTipoCliente")
                )
                );
            }

            rs.close();
            stmt.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        listaClientes = FXCollections.observableArrayList(lista);
        return listaClientes;

    }

    public ObservableList<Administracion> getAdministracion() {

        ArrayList<Administracion> lista = new ArrayList<Administracion>();

        try {

            PreparedStatement stmt;

            stmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarAdministracion()}");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                lista.add(new Administracion(
                        rs.getInt("id"),
                        rs.getString("direccion"),
                        rs.getString("telefono")
                )
                );
            }

            rs.close();
            stmt.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        listaAdministracion = FXCollections.observableArrayList(lista);
        return listaAdministracion;
    }

    public ObservableList<TipoCliente> getTipoCliente() {
        ArrayList<TipoCliente> lista = new ArrayList<TipoCliente>();

        try {
            PreparedStatement pstmt;

            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarTipoCliente()}");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                lista.add(new TipoCliente(rs.getInt("id"), rs.getString("descripcion")));
            }

            rs.close();
            pstmt.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        listaTipoClientes = FXCollections.observableArrayList(lista);
        return listaTipoClientes;
    }

    public ObservableList<Locales> getLocales() {
        ArrayList<Locales> lista = new ArrayList<Locales>();

        try {
            PreparedStatement stmt;

            stmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarLocales()}");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                lista.add(new Locales(
                        rs.getInt("id"),
                        rs.getBigDecimal("saldoFavor"),
                        rs.getBigDecimal("saldoContra"),
                        rs.getInt("mesesPendientes"),
                        rs.getBoolean("disponibilidad"),
                        rs.getBigDecimal("valorLocal"),
                        rs.getBigDecimal("valorAdministracion")
                )
                );
            }

            rs.close();
            stmt.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        listaLocales = FXCollections.observableArrayList(lista);
        return listaLocales;

    }

    private TipoCliente buscarTipoCliente(int id) {

        TipoCliente registro = null;

        try {

            PreparedStatement pstmt;

            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_BuscarTipoCliente(?)}");
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {

                registro = new TipoCliente(rs.getInt("id"), rs.getString("descripcion"));

            }

            rs.close();
            pstmt.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return registro;
    }

      
    
    
    
    public void agregarClientes() {

        ArrayList<TextField> listaTextField = new ArrayList<>();
        listaTextField.add(txtNombre);
        listaTextField.add(txtApellidos);
        listaTextField.add(txtDireccion);
        listaTextField.add(txtTelefono);

        ArrayList<ComboBox> listaComboBox = new ArrayList<>();
         listaComboBox.add(cmbTipoCliente);
         listaComboBox.add(cmbLocal);
         listaComboBox.add(cmbAdministracion);
         

        if (escenarioPrincipal.validar(listaTextField, listaComboBox)) {

            Clientes registro = new Clientes();
            registro.setNombres(txtNombre.getText());
            registro.setApellidos(txtApellidos.getText());
            registro.setDireccion(txtDireccion.getText());
            registro.setTelefono(txtTelefono.getText());
            registro.setEmail(txtEmail.getText());

            registro.setIdTipoCliente(((TipoCliente) cmbTipoCliente.getSelectionModel().getSelectedItem()).getId());
            registro.setIdLocal(((Locales) cmbLocal.getSelectionModel().getSelectedItem()).getId());
            registro.setIdAdministracion(((Administracion) cmbAdministracion.getSelectionModel().getSelectedItem()).getId());
            try {
             
                PreparedStatement stmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_AgregarClientes(?,?,?,?,?,?,?,?)}");
                stmt.setString(1, registro.getNombres());
                stmt.setString(2, registro.getApellidos());
                stmt.setString(3, registro.getTelefono());
                stmt.setString(4, registro.getDireccion());
                stmt.setString(5, registro.getEmail());
                stmt.setInt(6, registro.getIdTipoCliente());
                stmt.setInt(7, registro.getIdLocal());
                stmt.setInt(8, registro.getIdAdministracion());

                
                stmt.execute();

            } catch (Exception e) {
                e.printStackTrace();
            }
        } 
    }
    
    
     private void editarClientes() {
        ArrayList<TextField> listaTextField = new ArrayList<>();
        listaTextField.add(txtId);
        listaTextField.add(txtNombre);
        listaTextField.add(txtApellidos);
        listaTextField.add(txtDireccion);
        listaTextField.add(txtTelefono);
        listaTextField.add(txtEmail);

        ArrayList<ComboBox> listaComboBox = new ArrayList<>();
        listaComboBox.add(cmbTipoCliente);
        listaComboBox.add(cmbLocal);
        listaComboBox.add(cmbAdministracion);

        if (this.escenarioPrincipal.validar(listaTextField, listaComboBox)) {
            Clientes cliente = new Clientes();

            cliente.setId(Integer.parseInt(txtId.getText()));
            cliente.setNombres(txtNombre.getText());
            cliente.setApellidos(txtApellidos.getText());
            cliente.setTelefono(txtTelefono.getText());
            cliente.setDireccion(txtDireccion.getText());
            cliente.setEmail(txtEmail.getText());
            cliente.setIdTipoCliente(((TipoCliente) cmbTipoCliente.getSelectionModel().getSelectedItem()).getId());

            try {
                PreparedStatement stmt;
                stmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_EditarClientes(?, ?, ?,?,?,?,?,?,?)}");
                stmt.setInt(1, cliente.getId());
                stmt.setString(2, cliente.getNombres());
                stmt.setString(3, cliente.getApellidos());
                stmt.setString(4, cliente.getTelefono());
                stmt.setString(5, cliente.getDireccion());
                stmt.setString(6, cliente.getEmail());
                stmt.setInt(7, cliente.getIdTipoCliente());
                stmt.setInt(8, cliente.getIdLocal());
                stmt.setInt(9, cliente.getIdAdministracion());
                stmt.execute();

                System.out.println(stmt.toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }     }

  
     
       private void eliminarClientes() {

        if (tblClientes.getSelectionModel().getSelectedItem() != null) {
            try {
                PreparedStatement stmt;
                stmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_EliminarClientes(?)}");
                //stmt.setInt(1, Integer.parseInt(txtId.getText()));
                stmt.setInt(1, ((Clientes) tblClientes.getSelectionModel().getSelectedItem()).getId());
                stmt.execute();
                            
                } catch (Exception e) {
                e.printStackTrace();
            }
        } 
    }
     
    
    @FXML
    private void selecionarElemento(MouseEvent event) {
         txtId.setText(String.valueOf(((Clientes) tblClientes.getSelectionModel().getSelectedItem()).getId()));
            txtNombre.setText(((Clientes) tblClientes.getSelectionModel().getSelectedItem()).getNombres());
            txtApellidos.setText(((Clientes) tblClientes.getSelectionModel().getSelectedItem()).getApellidos());
            txtTelefono.setText(((Clientes) tblClientes.getSelectionModel().getSelectedItem()).getTelefono());
            txtDireccion.setText(((Clientes) tblClientes.getSelectionModel().getSelectedItem()).getDireccion());
            txtEmail.setText(((Clientes) tblClientes.getSelectionModel().getSelectedItem()).getEmail());

            cmbTipoCliente.getSelectionModel().select(buscarTipoCliente(((Clientes) tblClientes.getSelectionModel().getSelectedItem()).getIdTipoCliente()));
           
    }

   private void desactivarControles() {
        txtId.setEditable(false);
        txtNombre.setEditable(false);
        txtApellidos.setEditable(false);
        txtDireccion.setEditable(false);
        txtTelefono.setEditable(false);
        txtEmail.setEditable(false);
        cmbTipoCliente.setDisable(true);
        cmbLocal.setDisable(true);
        cmbAdministracion.setDisable(true);
    }

    private void activarControles() {
        txtId.setEditable(false);
        txtNombre.setEditable(true);
        txtApellidos.setEditable(true);
        txtDireccion.setEditable(true);
        txtTelefono.setEditable(true);
        txtEmail.setEditable(true);
        cmbTipoCliente.setDisable(false);
        cmbLocal.setDisable(false);
        cmbAdministracion.setDisable(false);
    }

    private void limpiarControles() {
        txtId.clear();
        txtNombre.clear();
        txtApellidos.clear();
        txtDireccion.clear();
        txtTelefono.clear();
        txtEmail.clear();
        cmbTipoCliente.valueProperty().set(null);
        cmbLocal.valueProperty().set(null);
        cmbAdministracion.valueProperty().set(null);
    }
    
     public boolean existeElementoSeleccionado() {

        if (tblClientes.getSelectionModel().getSelectedItem() == null) {
            return false;
        } else {
            return true;
        }
    }
    
    
    
    public boolean validarEmail(String email) {

        Pattern pattern = Pattern.compile("^[\\w-]+(\\.[\\w-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    public boolean validarTelefono(String numero) {

        Pattern pattern = Pattern.compile("^[0-9]{8}$");
        Matcher matcher = pattern.matcher(numero);
        return matcher.matches();
    }
    
    
    
    
    @FXML
    private void nuevo(ActionEvent event) {
          switch (operacion) {
            case NINGUNO:
                activarControles();
                limpiarControles();
                btnNuevo.setText("Guardar");
                btnEliminar.setText("Cancelar");
                imgNuevo.setImage(new Image(PACK_IMAGEN + "Guardar.png"));
                imgEliminar.setImage(new Image(PACK_IMAGEN + "Cancelar.png"));
                
                btnEditar.setDisable(true);
                btnReporte.setDisable(true);
                operacion = Operaciones.GUARDAR;
                break;
                
                
            case GUARDAR:
                
                 if (txtDireccion.getText().isEmpty()) {
                     
                    Alert a1 = new Alert(Alert.AlertType.INFORMATION);
                    a1.setTitle("Verifica");
                    a1.setHeaderText(null);
                    a1.setContentText("Debe llenar los datos solicitados");
                    a1.showAndWait();
                } else {
                
                if (validarTelefono(txtTelefono.getText())) {
                    
                    if (validarEmail(txtEmail.getText())) {
                        agregarClientes();
                        cargarDatos();
                        desactivarControles();
                        limpiarControles();

                        btnNuevo.setText("Nuevo");
                        btnEliminar.setText("Eliminar");
                        imgNuevo.setImage(new Image(PACK_IMAGEN + "Agregar.png"));
                        imgEliminar.setImage(new Image(PACK_IMAGEN + "Eliminar.png"));
                        btnEditar.setDisable(false);
                        btnReporte.setDisable(false);
                        operacion = Operaciones.NINGUNO;
                        
                        
                        
                    } else {
                        Alert vacio = new Alert(Alert.AlertType.ERROR);
                        vacio.setTitle("Error");
                        vacio.setContentText("Verifique que el email este correctamente escrito");
                        vacio.setHeaderText(null);
                        vacio.show();
                    }
                } else {
                    Alert vacio = new Alert(Alert.AlertType.ERROR);
                    vacio.setTitle("Error");
                    vacio.setContentText("El numero supera los 8 digitos seleccionados o no tiene la cantidad necesaria");
                    vacio.setHeaderText(null);
                    vacio.show();
                }
                break;
        }
        }
    }

    
    
    @FXML
    private void eliminar(ActionEvent event) {
        
         switch (operacion) {
            case GUARDAR:
                btnNuevo.setText("Nuevo");
                btnEliminar.setText("Eliminar");
                imgNuevo.setImage(new Image(PACK_IMAGEN + "Agregar.png"));
                imgEliminar.setImage(new Image(PACK_IMAGEN + "Eliminar.png"));
                
                btnEditar.setDisable(false);
                btnReporte.setDisable(false);
                limpiarControles();
                desactivarControles();
                operacion = Operaciones.NINGUNO;
                break;
           
            case NINGUNO:
                 if (existeElementoSeleccionado()) {
                                        
                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("¿Desea eliminar este registro?");
                     Optional<ButtonType> respuesta = alert.showAndWait();
                    if (respuesta.get() == ButtonType.OK) {
                        eliminarClientes();
                        limpiarControles();
                        cargarDatos();                        
                    }
                    
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Es necesario que seleccione un registro");
                    alert.show();
                }
             break;           
        }      
    }
    
    
    
    
    
    @FXML
    private void editar(ActionEvent event) {
        
         switch (operacion) {
            case NINGUNO:
           
                if (tblClientes.getSelectionModel().getSelectedItem() != null) {
                    
                    activarControles();
                    btnEditar.setText("Actualizar");
                    btnReporte.setText("Cancelar");
                    imgEditar.setImage(new Image(PACK_IMAGEN + "Guardar.png"));
                    imgReporte.setImage(new Image(PACK_IMAGEN + "Cancelar.png"));
                   
                    
                    btnNuevo.setDisable(true);
                    btnEliminar.setDisable(true);
                    operacion = Operaciones.ACTUALIZAR;
                } else {
                    Alert a1ert = new Alert(Alert.AlertType.INFORMATION);
                    a1ert.setTitle("Kinal Mall");
                    a1ert.setHeaderText(null);
                    a1ert.setContentText("Seleccione un registro para editarlo");
                    a1ert.showAndWait();
                }
                break;
            case ACTUALIZAR:
                
                if (validarTelefono(txtTelefono.getText())) {
                    
                    if (validarEmail(txtEmail.getText())) {
            
                editarClientes();
                limpiarControles();
                desactivarControles();
                cargarDatos();
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                btnEditar.setText("Editar");
                btnReporte.setText("Reporte");
                 imgEditar.setImage(new Image(PACK_IMAGEN + "Editar.png"));
                 imgReporte.setImage(new Image(PACK_IMAGEN + "Reporte.png"));
                operacion = Operaciones.NINGUNO;

                
                 } else {
                        Alert vacio = new Alert(Alert.AlertType.ERROR);
                        vacio.setTitle("Error");
                        vacio.setContentText("Verifique que el email este correctamente escrito");
                        vacio.setHeaderText(null);
                        vacio.show();
                       
                    }
                } else {
                    Alert vacio = new Alert(Alert.AlertType.ERROR);
                    vacio.setTitle("Error");
                    vacio.setContentText("El numero supera los 8 digitos seleccionados o no tiene la cantidad necesaria");
                    vacio.setHeaderText(null);
                    vacio.show();
                }
                
                break;
                
        
        
    }

    }

    @FXML
    private void reporte(ActionEvent event) {
     switch (operacion) {
            case ACTUALIZAR:
                btnEditar.setText("Editar");
                btnReporte.setText("Reporte");
                imgEditar.setImage(new Image(PACK_IMAGEN + "Editar.png"));
                imgReporte.setImage(new Image(PACK_IMAGEN + "Reporte.png"));
                
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                operacion = Operaciones.NINGUNO;
                break;
        }
    
    
    
    }

     
    
}
