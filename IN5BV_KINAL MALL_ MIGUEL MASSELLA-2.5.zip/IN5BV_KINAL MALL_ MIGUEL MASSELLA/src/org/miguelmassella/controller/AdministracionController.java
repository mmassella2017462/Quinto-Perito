/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.miguelmassella.controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.input.MouseEvent;
import org.miguelmassella.db.Conexion;
import org.miguelmassella.system.Principal;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javax.swing.JOptionPane;

import org.miguelmassella.bean.Administracion;

import javafx.scene.control.TextField;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import org.miguelmassella.report.GenerarReporte;




/**
 *
 * @author migue
 * @date 26/05/2021
 * @time 15:40:30
 * @code IN5BV
*/
public class AdministracionController implements Initializable{

    private Principal escenarioPrincipal;

   
    
    private enum Operaciones{NUEVO, GUARDAR, EDITAR, ELIMINAR, 
                                ACTUALIZAR, CANCELAR, NINGUNO};
    
    private Operaciones operacion = Operaciones.NINGUNO;
    
    private ObservableList<Administracion> listadoAdministracion;
     
    
     private final String PACK_IMAGEN = "/org/miguelmassella/resource/image/" ; 
    
    
    @FXML
    private Button btnNuevo;
    
    @FXML
    private ImageView imgNuevo;
    
    @FXML
    private Button btnEditar;
    
    @FXML
    private ImageView imgEditar;
 
    @FXML
    private Button btnEliminar;
    
    @FXML
    private ImageView imgEliminar;
    
    @FXML
    private Button btnReporte;
    
    @FXML
    private ImageView imgReporte;
    
    @FXML
    private TextField txtId;
    
    @FXML
    private TextField txtDireccion;
    
    @FXML
    private TextField txtTelefono;
    
    @FXML
    private TableColumn colId;
    
    @FXML
    private TableColumn colDireccion;
    
    @FXML
    private TableColumn colTelefono;
    
    @FXML
    private TableView tblAdministracion;
    
     
  
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        CargarDatos();
    
    }

    public Principal getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }

    @FXML
    private void MostrarPrincipal(MouseEvent event) {
         escenarioPrincipal.mostrarMenuPrincipal();
    }

     @FXML
    private void mostrarLocales(ActionEvent event) {
        escenarioPrincipal.mostrarLocales();
                
    }
    
     @FXML
    private void mostrarCargos(ActionEvent event) {
        escenarioPrincipal.mostrarCargos();
    }

    @FXML
    private void mostrarDepas(ActionEvent event) {
        escenarioPrincipal.mostrarDepartamentos();
    }

    @FXML
    private void mostrarTipoClientes(ActionEvent event) {
        escenarioPrincipal.MostrarTipoClientes();
    }
    
    
    
    
    
    
    
    public ObservableList<Administracion> getAdministracion(){
        
        ArrayList<Administracion> listado = new ArrayList<Administracion>();
        
        
        try {   
            //CallableStatement stmt;
            PreparedStatement stmt;
            stmt= Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarAdministracion()}");
            ResultSet resultado = stmt.executeQuery();
            
            while (resultado.next()){
                listado.add(new Administracion(
                                resultado.getInt("id"),
                                resultado.getString("direccion"), 
                                resultado.getString("telefono")
                )   );
            }
            
            resultado.close();
            stmt.close();
            
            
        }catch( SQLException e){
            e.printStackTrace();
        } 
       listadoAdministracion = FXCollections.observableArrayList(listado);
       
        return listadoAdministracion;
                
    }
    
     
    private void habitilarCampos() {
        txtId.setEditable(false);
        txtDireccion.setEditable(true);
        txtTelefono.setEditable(true);

    }
  
    
    public void desabilitarControles() {
        txtId.setEditable(true);
        txtDireccion.setEditable(false);
        txtTelefono.setEditable(false);
        btnNuevo.setDisable(false);
    }

    public void limpiarCampos() {
        txtId.clear();
        txtDireccion.clear();
        txtTelefono.clear();
    }
       
    @FXML
    public void selecionarElemento() {
        txtId.setText(String.valueOf(((Administracion) tblAdministracion.getSelectionModel().getSelectedItem()).getId()));
        txtDireccion.setText(((Administracion) tblAdministracion.getSelectionModel().getSelectedItem()).getDireccion());
        txtTelefono.setText(((Administracion) tblAdministracion.getSelectionModel().getSelectedItem()).getTelefono());
    }
        
      public void agregarAdministracion() {

        Administracion registro = new Administracion();
        registro.setDireccion(txtDireccion.getText());
        registro.setTelefono(txtTelefono.getText());

        try {
            PreparedStatement stmt;
            stmt = Conexion.getInstance().getConexion().prepareCall("{call sp_AgregarAdministracion(?,?)}");
            stmt.setString(1, registro.getDireccion());
            stmt.setString(2, registro.getTelefono());
            stmt.execute();
        } catch (Exception e) {
            e.printStackTrace(); }
    }

       private void editarAdministracion() {

        Administracion registro = new Administracion();

        registro.setId(Integer.parseInt(txtId.getText()));
        registro.setDireccion(txtDireccion.getText());
        registro.setTelefono(txtTelefono.getText());

        try {
            PreparedStatement stmt;
            stmt = Conexion.getInstance().getConexion().prepareCall("{call sp_EditarAdministracion(?, ?, ?)}");
            stmt.setInt(1, registro.getId());
            stmt.setString(2, registro.getDireccion());
            stmt.setString(3, registro.getTelefono());
            stmt.execute();
            System.out.println(stmt.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

           
       private void eliminarAdministracion() {

        try {
            PreparedStatement stmt;
            stmt = Conexion.getInstance().getConexion().prepareCall("{call sp_EliminarAdministracion(?)}");
            stmt.setInt(1, Integer.parseInt(txtId.getText()));
            stmt.execute();
            System.out.println(stmt.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    
    
    public void CargarDatos(){
       
       tblAdministracion.setItems(getAdministracion());
       colId.setCellValueFactory( new PropertyValueFactory<Administracion, Integer>("id"));
       colDireccion.setCellValueFactory(new PropertyValueFactory<Administracion, String>("Direccion"));
       colTelefono.setCellValueFactory(new PropertyValueFactory<Administracion, String>("Telefono"));
    }

    
    public boolean existeElementoSeleccionado() {

        if (tblAdministracion.getSelectionModel().getSelectedItem() == null) {
            return false;
        } else {
            return true;
        }
    }
    
    
    
    
    
    
    
     @FXML
    private void nuevo(ActionEvent event) {
        System.out.println("Operaciones" + operacion);
        
                switch (operacion) {
            case NINGUNO:
                habitilarCampos();
                btnNuevo.setText("Guardar");
                btnEliminar.setText("Cancelar");
                imgNuevo.setImage(new Image(PACK_IMAGEN + "Guardar.png"));
                imgEliminar.setImage(new Image(PACK_IMAGEN + "Cancelar.png"));
                btnEditar.setDisable(true);
                btnReporte.setDisable(true);
                operacion = Operaciones.GUARDAR;
                break;
              
            case GUARDAR:
                if (txtDireccion.getText().isEmpty()) {             
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Necesita agregar la Informacion");
                    alert.show();
                } else {
                    btnNuevo.setDisable(false);
                    agregarAdministracion();
                    CargarDatos();
                    limpiarCampos();
                    btnNuevo.setText("Nuevo");
                    btnEliminar.setText("Eliminar");
                    imgNuevo.setImage(new Image(PACK_IMAGEN + "Agregar.png"));
                    imgEliminar.setImage(new Image(PACK_IMAGEN + "Eliminar.png"));
                    btnEditar.setDisable(false);
                    btnReporte.setDisable(false);
                    operacion = Operaciones.NINGUNO;
                }
                break;                
        }
        System.out.println("Operación: " + operacion);
    }

    
    @FXML
    private void editar(ActionEvent event) {
       System.out.println("Operacion" + operacion);
       
       switch (operacion){
           case NINGUNO:
                habitilarCampos();
                btnEditar.setText("Actualizar");
                btnReporte.setText("Cancelar");
                 imgEditar.setImage(new Image(PACK_IMAGEN + "Guardar.png"));
                 imgReporte.setImage(new Image(PACK_IMAGEN + "Cancelar.png"));
                btnNuevo.setDisable(true);
                btnEliminar.setDisable(true);
                operacion = Operaciones.ACTUALIZAR;
                break;
            case ACTUALIZAR:
                
                if (txtId.getText().isEmpty()) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Necesita seleccionar un registro para continuar");
                    alert.show();
                } else {
                editarAdministracion();
                limpiarCampos();
                desabilitarControles();
                CargarDatos();
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                btnEditar.setText("Editar");
                btnReporte.setText("Reporte");
                 imgEditar.setImage(new Image(PACK_IMAGEN + "Editar.png"));
                 imgReporte.setImage(new Image(PACK_IMAGEN + "Reporte.png"));
                operacion = Operaciones.NINGUNO;
                break;
                }
                 System.out.println("Operación: " + operacion);
        }
    }
         
    
    @FXML
    private void eliminar(ActionEvent event) {
        System.out.println("Operación: " + operacion);
        
        switch (operacion) {
            
            case GUARDAR:
                btnNuevo.setText("Nuevo");
                btnEliminar.setText("Eliminar");
                 imgNuevo.setImage(new Image(PACK_IMAGEN + "Agregar.png"));
                 imgEliminar.setImage(new Image(PACK_IMAGEN + "Eliminar.png"));
                btnEditar.setDisable(false);
                btnReporte.setDisable(false);
                limpiarCampos();
                desabilitarControles();
                operacion = Operaciones.NINGUNO;
                break;
                
            case NINGUNO: //Eliminar
                if (txtId.getText().isEmpty()) {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Debe seleccionar el registro a eliminar");
                    alert.show();
                } else {
                     Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("¿Está seguro que desea eliminar este registro?");
                    
                    Optional<ButtonType> respuesta = alert.showAndWait();
                    
                    if (respuesta.get() == ButtonType.OK) {
                        eliminarAdministracion();
                        limpiarCampos();
                        CargarDatos();                  
                }                
                break; 
        }
        System.out.println("Operación: " + operacion);            
   }
}

 @FXML
    private void reporte(ActionEvent event) {
        System.out.println("Operación: " + operacion);
        switch (operacion) {
            case ACTUALIZAR:
                btnEditar.setText("Editar");
                btnReporte.setText("Reportar");
                 imgEditar.setImage(new Image(PACK_IMAGEN + "Editar.png"));
                 imgReporte.setImage(new Image(PACK_IMAGEN + "Reporte.png"));
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                limpiarCampos();
                desabilitarControles();
                operacion = Operaciones.NINGUNO;
                break;
                
                
            case NINGUNO: //
                Map parametros = new HashMap();
                
                if(existeElementoSeleccionado()){
                int idAdministracion = ((Administracion)tblAdministracion.getSelectionModel().getSelectedItem()).getId();
                
                }else{               
                GenerarReporte.getInstance().mostrarReporte("ReporteAdministracion.jasper", "Reporte Administracion", parametros);
                }
                
                
        }
        System.out.println("Operación: " + operacion);
    }
    
    
    
    
    }




 
    
    
    

