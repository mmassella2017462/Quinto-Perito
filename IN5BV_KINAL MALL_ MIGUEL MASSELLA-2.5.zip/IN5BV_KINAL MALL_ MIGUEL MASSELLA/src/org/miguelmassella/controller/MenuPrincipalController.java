/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.miguelmassella.controller;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import org.miguelmassella.system.Principal;

/**
 *
 * @author migue
 * @date 12/05/2021
 * @time 18:09:02
 * @code IN5BV
*/
public class MenuPrincipalController  implements Initializable{
    
    private Principal escenarioPrincipal;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    
    }

    public Principal getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }

    @FXML
    private void MostrarVistaAutor(ActionEvent event) {
        escenarioPrincipal.mostrarAutor();
    }
    
    @FXML
    private void MostrarAdministracion(){
        escenarioPrincipal.mostrarAdministracion();
    }

   

    @FXML
    private void MostrarClientes(ActionEvent event) {
        escenarioPrincipal.mostrarClientes();
    }

  

    @FXML
    private void mostrarProveedores(ActionEvent event) {
        escenarioPrincipal.mostrarProveedores();
    }

    @FXML
    private void mostrarEmpleados(ActionEvent event) {
        escenarioPrincipal.mostrarEmpleados();
    }

    
}
