/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.miguelmassella.controller;

import java.math.BigDecimal;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import org.miguelmassella.bean.Administracion;
import org.miguelmassella.bean.Clientes;
import org.miguelmassella.bean.CuentasPorCobrar;
import org.miguelmassella.bean.Locales;
import org.miguelmassella.db.Conexion;
import org.miguelmassella.system.Principal;

/**
 *
 * @author migue
 * @date 22/07/2021
 * @time 00:46:21
 * @code IN5BV
*/
public class CuentasPorCobrarController implements Initializable {

    private Principal escenarioPrincipal;
    
     private final String PACK_IMAGEN = "/org/miguelmassella/resource/image/" ;
    
     private ObservableList<Locales>listaLocales;
     private ObservableList<Administracion> listaAdministracion;
     private ObservableList<Clientes> listaClientes;
     private ObservableList<CuentasPorCobrar> listaCuentasPorCobrar;
     
     private enum Operaciones {
        NUEVO, GUARDAR, ACTUALIZAR, ELIMINAR, CANCELAR, NINGUNO}
    
    private Operaciones operacion = Operaciones.NINGUNO;
   
    @FXML
    private Button btnNuevo;
    @FXML
    private ImageView imgNuevo;
    @FXML
    private Button btnEliminar;
    @FXML
    private ImageView imgEliminar;
    @FXML
    private Button btnEditar;
    @FXML
    private ImageView imgEditar;
    @FXML
    private Button btnReporte;
    @FXML
    private ImageView imgReporte;
    @FXML
    private TableView tblCuentasPorCobrar;
    @FXML
    private TableColumn colId;
    @FXML
    private TableColumn colFactura;
    @FXML
    private TableColumn colAnio;
    @FXML
    private TableColumn colMes;
    @FXML
    private TableColumn colValorNeto;
    @FXML
    private TableColumn colEstadoPago;
    @FXML
    private TableColumn colIdAdministracion;
    @FXML
    private TableColumn colIdCliente;
    @FXML
    private TableColumn colIdLocal;
    @FXML
    private TextField txtId;
    @FXML
    private TextField txtNumeroFactura;
    @FXML
    private TextField txtValorNeto;
    @FXML
    private ComboBox cmbAdministracion;
    @FXML
    private ComboBox cmbCliente;
    @FXML
    private ComboBox cmbLocal;
    @FXML
    private ComboBox cmbEstadoPago;

    @FXML
    private Spinner<Integer> spnAnio;
    
    private SpinnerValueFactory<Integer> valueFactoryAnio;
    
    @FXML
    private Spinner<Integer> spnMes;
    
    private SpinnerValueFactory<Integer> valueFactoryMes;
    
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        valueFactoryAnio = new SpinnerValueFactory.IntegerSpinnerValueFactory(2020, 2050, 2021);
        spnAnio.setValueFactory(valueFactoryAnio);

        valueFactoryMes = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 12, 6);
        spnMes.setValueFactory(valueFactoryMes);
        
        ObservableList<String> listaOpciones = FXCollections.observableArrayList( "PENDIENTE","CANCELADO");
        cmbEstadoPago.getItems().addAll(listaOpciones);
        
        cargarDatos();
        
    }

    public Principal getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
    
     @FXML
    private void mostrarClientes(MouseEvent event) {
        escenarioPrincipal.mostrarClientes();
    }

    
     public ObservableList<CuentasPorCobrar> getCuentasPorCobrar() {
        ArrayList<CuentasPorCobrar> listado = new ArrayList<>();
        
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarCuentasPorCobrar}");
            System.out.println(pstmt);    
            rs = pstmt.executeQuery();
            
            while(rs.next()) {
                listado.add(new CuentasPorCobrar(
                        rs.getInt("id"), 
                        rs.getString("numeroFactura"), 
                        rs.getInt("anio"), 
                        rs.getInt("mes"), 
                        rs.getBigDecimal("valorNetoPago"), 
                        rs.getString("estadoPago"), 
                        rs.getInt("idAdministracion"), 
                        rs.getInt("idCliente"), 
                        rs.getInt("idLocal")
                    )
                );
            }
            
            listaCuentasPorCobrar = FXCollections.observableArrayList(listado);
            
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar consultar la tabla Cuentas por cobrar de la base de datos.");
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
                pstmt.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        
        return listaCuentasPorCobrar;
    }
    
    
    
      public ObservableList<Administracion> getAdministracion() {
        ArrayList<Administracion> listado = new ArrayList<Administracion>();
        PreparedStatement stmt = null;
        ResultSet resultado = null;
        try {
            
            stmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarAdministracion()}");
            resultado = stmt.executeQuery();

            while (resultado.next()) {
                listado.add(new Administracion(
                        resultado.getInt("id"),
                        resultado.getString("direccion"),
                        resultado.getString("telefono")
                )
                );
            }
            listaAdministracion = FXCollections.observableArrayList(listado);
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar consultar la tabla Administración en la base de datos.");
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                resultado.close();
                stmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return listaAdministracion;
    }

      
      
        public ObservableList<Locales> getLocales() {
        ArrayList<Locales> lista = new ArrayList<>();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarLocales}");
            rs = pstmt.executeQuery();
            while (rs.next()) {
                lista.add(new Locales(
                        rs.getInt("id"), 
                        rs.getBigDecimal("saldoFavor"), 
                        rs.getBigDecimal("saldoContra"), 
                        rs.getInt("mesesPendientes"), 
                        rs.getBoolean("disponibilidad"),                         
                        rs.getBigDecimal("valorLocal"), 
                        rs.getBigDecimal("valorAdministracion"))
                );
            }
            listaLocales = FXCollections.observableArrayList(lista);
            
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar consultar la tabla Locales en la base de datos.");
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
                pstmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        
        return listaLocales;
    }

        
        
        public ObservableList<Clientes> getClientes() {
        ArrayList<Clientes> lista = new ArrayList<>();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarClientes}");
            rs = pstmt.executeQuery();
            while (rs.next()) {
                lista.add(new Clientes(
                        rs.getInt("id"),
                        rs.getString("nombres"),
                        rs.getString("apellidos"),
                        rs.getString("telefono"),
                        rs.getString("direccion"),
                        rs.getString("email"),
                        rs.getInt("idLocal"),
                        rs.getInt("idAdministracion"),
                        rs.getInt("idTipoCliente")
                )
                );
            }
            listaClientes = FXCollections.observableArrayList(lista);
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar consultar la tabla Clientes en la base de datos.");
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
                pstmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        return listaClientes;
    }
    
        
        
         public Clientes buscarCliente(int id) {
        Clientes cliente = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_BuscarClientes(?)}");
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                cliente = new Clientes(
                        rs.getInt("id"), 
                        rs.getString("nombres"), 
                        rs.getString("apellidos"), 
                        rs.getString("telefono"), 
                        rs.getString("direccion"), 
                        rs.getString("email"), 
                        rs.getInt("idLocal"),
                        rs.getInt("idAdministracion"),
                        rs.getInt("idTipoCliente")
                );
            }
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar consultar la tabla Clientes del registro con el ID: " + id);
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
                pstmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return cliente;
    }
         
         
         
          public Locales buscarLocal(int id) {
        Locales local = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_BuscarLocales(?)}");
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                local = new Locales(
                        rs.getInt("id"),
                        rs.getBigDecimal("saldoFavor"), 
                        rs.getBigDecimal("saldoContra"), 
                        rs.getInt("mesesPendientes"), 
                        rs.getBoolean("disponibilidad"), 
                        rs.getBigDecimal("valorLocal"), 
                        rs.getBigDecimal("valorAdministracion")
                );
            }
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar consultar la tabla Locales del registro con el ID: " + id);
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
                pstmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return local;
    }    

          
          
          public Administracion buscarAdministracion(int id) {
        Administracion administracion = null;
        
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_BuscarAdministracion(?)}");
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                administracion = new Administracion(
                        rs.getInt("id"), 
                        rs.getString("direccion"), 
                        rs.getString("telefono")
                );
            }
            
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar buscar una Administracion con el ID " + id);
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
                pstmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
                    
        return administracion;
    }
    
          
          public void agregarCuentasPorCobrar() {
        CuentasPorCobrar cuentaCobrar = new CuentasPorCobrar();
        cuentaCobrar.setNumeroFactura(txtNumeroFactura.getText());
        cuentaCobrar.setAnio(spnAnio.getValue());
        cuentaCobrar.setMes(spnMes.getValue());
        cuentaCobrar.setValorNetoPago(new BigDecimal(txtValorNeto.getText()));
        cuentaCobrar.setEstadoPago(cmbEstadoPago.getValue().toString());
        cuentaCobrar.setIdAdministracion(((Administracion)cmbAdministracion.getSelectionModel().getSelectedItem()).getId());
        cuentaCobrar.setIdCliente(((Clientes) cmbCliente.getSelectionModel().getSelectedItem()).getId());
        cuentaCobrar.setIdLocal(((Locales) cmbLocal.getSelectionModel().getSelectedItem()).getId());
        
        PreparedStatement pstmt = null;
        
        try {
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_AgregarCuentasPorCobrar(?, ?, ?, ?, ?, ?, ?, ?)}");
            pstmt.setString(1, cuentaCobrar.getNumeroFactura());
            pstmt.setInt(2, cuentaCobrar.getAnio());
            pstmt.setInt(3, cuentaCobrar.getMes());
            pstmt.setBigDecimal(4, cuentaCobrar.getValorNetoPago());
            pstmt.setString(5, cuentaCobrar.getEstadoPago());
            pstmt.setInt(6, cuentaCobrar.getIdAdministracion());
            pstmt.setInt(7, cuentaCobrar.getIdCliente());
            pstmt.setInt(8, cuentaCobrar.getIdLocal());
            
            System.out.println(pstmt);
            
            pstmt.execute();
            
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar agregar una nueva Cuenta por cobrar");
            e.printStackTrace();
        } finally {
            try {
                pstmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
          
          
           public void editarCuentasPorCobrar() {
        CuentasPorCobrar cuentaCobrar = new CuentasPorCobrar();
        cuentaCobrar.setId(Integer.parseInt(txtId.getText()));
        cuentaCobrar.setNumeroFactura(txtNumeroFactura.getText());
        cuentaCobrar.setAnio(spnAnio.getValue());
        cuentaCobrar.setMes(spnMes.getValue());
        cuentaCobrar.setValorNetoPago(new BigDecimal(txtValorNeto.getText()));
        cuentaCobrar.setEstadoPago(cmbEstadoPago.getValue().toString());
        cuentaCobrar.setIdAdministracion(((Administracion)cmbAdministracion.getSelectionModel().getSelectedItem()).getId());
        cuentaCobrar.setIdCliente(((Clientes) cmbCliente.getSelectionModel().getSelectedItem()).getId());
        cuentaCobrar.setIdLocal(((Locales) cmbLocal.getSelectionModel().getSelectedItem()).getId());
        
        PreparedStatement pstmt = null;
        
        try {
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_EditarCuentasPorCobrar(?, ?, ?, ?, ?, ?, ?, ?, ?)}");
            
            pstmt.setInt(1, cuentaCobrar.getId());
            
            pstmt.setString(2, cuentaCobrar.getNumeroFactura());
            pstmt.setInt(3, cuentaCobrar.getAnio());
            pstmt.setInt(4, cuentaCobrar.getMes());
            pstmt.setBigDecimal(5, cuentaCobrar.getValorNetoPago());
            pstmt.setString(6, cuentaCobrar.getEstadoPago());
            pstmt.setInt(7, cuentaCobrar.getIdAdministracion());
            pstmt.setInt(8, cuentaCobrar.getIdCliente());
            pstmt.setInt(9, cuentaCobrar.getIdLocal());
            
            System.out.println(pstmt);
            
            pstmt.execute();
            
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar editar una Cuenta por cobrar");
            e.printStackTrace();
        } finally {
            try {
                pstmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }        
    }
    
          
           public void eliminarCuentasPorCobrar() {
        
        if (existeElementoSeleccionado()) {
            
            CuentasPorCobrar cuentaCobrar = (CuentasPorCobrar) tblCuentasPorCobrar.getSelectionModel().getSelectedItem();
            
            System.out.println(cuentaCobrar);
            
            PreparedStatement pstmt = null;
            
            try {
                pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_EliminarCuentasPorCobrar(?)}");
                
                pstmt.setInt(1,((CuentasPorCobrar) tblCuentasPorCobrar.getSelectionModel().getSelectedItem()).getId());

                
                System.out.println(pstmt);
                
                pstmt.execute();
                
                
            } catch (SQLException e) {
                System.err.println("\nSe produjo un error al intentar eliminar el registro con el id " + cuentaCobrar.getId());
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    pstmt.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        
    }
          
            
          
    
     public void cargarDatos() {
        tblCuentasPorCobrar.setItems(getCuentasPorCobrar());
        colId.setCellValueFactory(new PropertyValueFactory<CuentasPorCobrar, Integer>("id"));
        colFactura.setCellValueFactory(new PropertyValueFactory<CuentasPorCobrar, String>("numeroFactura"));
        colAnio.setCellValueFactory(new PropertyValueFactory<CuentasPorCobrar, Integer>("anio"));
        colMes.setCellValueFactory(new PropertyValueFactory<CuentasPorCobrar, Integer>("mes"));
        colValorNeto.setCellValueFactory(new PropertyValueFactory<CuentasPorCobrar, BigDecimal>("valorNetoPago"));
        colEstadoPago.setCellValueFactory(new PropertyValueFactory<CuentasPorCobrar, String>("estadoPago"));
        colIdAdministracion.setCellValueFactory(new PropertyValueFactory<CuentasPorCobrar, Integer>("idAdministracion"));
        colIdCliente.setCellValueFactory(new PropertyValueFactory<CuentasPorCobrar, Integer>("idCliente"));
        colIdLocal.setCellValueFactory(new PropertyValueFactory<CuentasPorCobrar, Integer>("idLocal"));
        
        cmbAdministracion.setItems(getAdministracion());
        cmbCliente.setItems(getClientes());
        cmbLocal.setItems(getLocales());
    }
    
     
      public boolean existeElementoSeleccionado() {
        return tblCuentasPorCobrar.getSelectionModel().getSelectedItem() != null;
    }
     
      @FXML
    private void seleccionarElemento(MouseEvent event) {
         if (existeElementoSeleccionado()) {
            
            txtId.setText(String.valueOf( ((CuentasPorCobrar) tblCuentasPorCobrar.getSelectionModel().getSelectedItem()).getId()));
            txtNumeroFactura.setText(((CuentasPorCobrar) tblCuentasPorCobrar.getSelectionModel().getSelectedItem()).getNumeroFactura());
            spnAnio.getValueFactory().setValue(((CuentasPorCobrar) tblCuentasPorCobrar.getSelectionModel().getSelectedItem()).getAnio());
            spnMes.getValueFactory().setValue(((CuentasPorCobrar) tblCuentasPorCobrar.getSelectionModel().getSelectedItem()).getMes());
            txtValorNeto.setText(String.valueOf(((CuentasPorCobrar) tblCuentasPorCobrar.getSelectionModel().getSelectedItem()).getValorNetoPago()));
            cmbEstadoPago.setValue(((CuentasPorCobrar)tblCuentasPorCobrar.getSelectionModel().getSelectedItem()).getEstadoPago());
            cmbAdministracion.getSelectionModel().select(buscarAdministracion(((CuentasPorCobrar) tblCuentasPorCobrar.getSelectionModel().getSelectedItem()).getIdAdministracion()));
            cmbCliente.getSelectionModel().select(buscarCliente( ((CuentasPorCobrar) tblCuentasPorCobrar.getSelectionModel().getSelectedItem()).getIdCliente() ));
            cmbLocal.getSelectionModel().select(buscarLocal(((CuentasPorCobrar) tblCuentasPorCobrar.getSelectionModel().getSelectedItem()).getIdLocal()));
        } else {
            Alert vacio = new Alert(Alert.AlertType.ERROR);
            vacio.setTitle("Error");
            vacio.setContentText("Este campo esta vacio");
            vacio.setHeaderText(null);
            vacio.show();
        }
    }

    
    
    
    public boolean validarDecimal(String numero){
        String patron = "^\\d{1,8}([.]\\d{1,2})?$";
        Pattern pattern = Pattern.compile(patron);
        Matcher matcher = pattern.matcher(numero);
        return matcher.matches();
    
    }
    
    private void activarControles() {
        txtId.setEditable(false);

        txtNumeroFactura.setEditable(true);
        txtValorNeto.setEditable(true);

        spnAnio.setDisable(false);
        spnMes.setDisable(false);

        cmbAdministracion.setDisable(false);
        cmbCliente.setDisable(false);
        cmbLocal.setDisable(false);
        cmbEstadoPago.setDisable(false);
    }

    public void limpiarControles() {
        txtId.clear();
        txtNumeroFactura.clear();
        txtValorNeto.clear();
        

        spnAnio.getValueFactory().setValue(2021);
        spnMes.getValueFactory().setValue(1);

        cmbAdministracion.valueProperty().set(null);
        cmbCliente.valueProperty().set(null);
        cmbLocal.valueProperty().set(null);
        cmbEstadoPago.setValue(null);
        
    }
    
    
    public void desactivarControles() {
        txtId.setEditable(false);
        txtNumeroFactura.setEditable(false);
        txtValorNeto.setEditable(false);
        
        
        spnAnio.setDisable(true);
        spnMes.setDisable(true);
        
        cmbAdministracion.setDisable(true);
        cmbCliente.setDisable(true);
        cmbLocal.setDisable(true);
        cmbEstadoPago.setDisable(true);
    }

    
    
    @FXML
    private void nuevo(ActionEvent event) {
        
          switch (operacion) {
            case NINGUNO:
                activarControles();
                limpiarControles();
                
                btnNuevo.setText("Guardar");
              
                
                btnEditar.setDisable(true);
                
                btnEliminar.setText("Cancelar");
                
                imgNuevo.setImage(new Image( PACK_IMAGEN+ "Guardar.png"));
                imgEliminar.setImage(new Image(PACK_IMAGEN + "Cancelar.png"));
                
                btnReporte.setDisable(true);
                
                operacion = Operaciones.GUARDAR;
                break;
                
            case GUARDAR:

                ArrayList<TextField> listaTextField = new ArrayList<>();
                listaTextField.add(txtNumeroFactura);
                listaTextField.add(txtValorNeto);
               

                ArrayList<ComboBox> listaComboBox = new ArrayList<>();
                listaComboBox.add(cmbAdministracion);
                listaComboBox.add(cmbCliente);
                listaComboBox.add(cmbLocal);
                listaComboBox.add(cmbEstadoPago);

                if (escenarioPrincipal.validar(listaTextField, listaComboBox)) {
                    if (validarDecimal(txtValorNeto.getText())) {
                        agregarCuentasPorCobrar();
                        cargarDatos();
                        desactivarControles();
                        limpiarControles();

                        btnNuevo.setText("Nuevo");
                        imgNuevo.setImage(new Image(PACK_IMAGEN + "Agregar.png"));

                        btnEliminar.setText("Eliminar");
                        imgEliminar.setImage(new Image(PACK_IMAGEN + "Eliminar.png"));

                        btnEditar.setDisable(false);
                        btnReporte.setDisable(false);

                        operacion = Operaciones.NINGUNO;
                    } else {
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("KINAL MALL");
                        alert.setHeaderText(null);
                        alert.setContentText("El campo Valor Neto Pago solo acepta numeros, numeros con dos decimales y de ocho digitos");
                        alert.show();

                    }
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Verifique que los campos tengan los datos solicitados");
                    alert.show();

                }

                break;
        }
        
        
        
    }

    @FXML
    private void eliminar(ActionEvent event) {
        
        switch (operacion) {
            case GUARDAR:
                
                btnNuevo.setText("Nuevo");
                btnEliminar.setText("Eliminar");
                
                imgNuevo.setImage(new Image(PACK_IMAGEN + "Agregar.png"));
                imgEliminar.setImage(new Image(PACK_IMAGEN + "Eliminar.png"));
                
                btnEditar.setDisable(false);
                btnReporte.setDisable(false);
                
                limpiarControles();
                desactivarControles();
                
                operacion = Operaciones.NINGUNO;
                break;
            case NINGUNO: // Eliminación
                if (existeElementoSeleccionado()) {
                                        
                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("¿Está seguro que desea eliminar este registro?");
                    
                    Optional<ButtonType> respuesta = alert.showAndWait();
                    
                    if (respuesta.get() == ButtonType.OK) {
                        eliminarCuentasPorCobrar();
                        limpiarControles();
                        cargarDatos();                        
                    }
                    
                    
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Debe seleccionar el registro que desea eliminar");
                    alert.show();
                }

                break;
        }
    }

    @FXML
    private void editar(ActionEvent event) {
        
          switch (operacion) {
            case NINGUNO:
                if (existeElementoSeleccionado()) {
                    activarControles();
                    
                    btnEditar.setText("Actualizar");   
                    btnReporte.setText("Cancelar");
                    imgEditar.setImage(new Image(PACK_IMAGEN + "Guardar.png"));
                    imgReporte.setImage(new Image(PACK_IMAGEN + "Cancelar.png"));
                    btnNuevo.setDisable(true);
                    btnEliminar.setDisable(true);
                    
                    operacion = Operaciones.ACTUALIZAR;
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Antes de continuar, selecciona un registro");
                    alert.show();
                }

                break;
                
            case ACTUALIZAR:
                
                ArrayList<TextField> listaTextField = new ArrayList<>();
                listaTextField.add(txtId);
                listaTextField.add(txtNumeroFactura);
                listaTextField.add(txtValorNeto);
                

                ArrayList<ComboBox> listaComboBox = new ArrayList<>();
                listaComboBox.add(cmbAdministracion);
                listaComboBox.add(cmbCliente);
                listaComboBox.add(cmbLocal);
                listaComboBox.add(cmbEstadoPago);

                if (escenarioPrincipal.validar(listaTextField, listaComboBox)) {
                    if (validarDecimal(txtValorNeto.getText())) {
                        editarCuentasPorCobrar();
                        limpiarControles();
                        desactivarControles();
                        cargarDatos();

                        btnNuevo.setDisable(false);
                        btnEliminar.setDisable(false);

                        btnEditar.setText("Editar");

                        btnReporte.setText("Reporte");
                        imgReporte.setImage(new Image(PACK_IMAGEN + "Reporte.png"));
                        imgEditar.setImage(new Image(PACK_IMAGEN + "Editar.png"));

                        operacion = Operaciones.NINGUNO;
                        break;
                    } else {
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("KINAL MALL");
                        alert.setHeaderText(null);
                        alert.setContentText("El campo Valor Neto Pago solo acepta numeros, numeros con dos decimales y de ocho digitos");
                        alert.show();
                    }
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Verifique que los campos contengan los datos necesarios");
                    alert.show();

                }

        }
        
        
    }

    @FXML
    private void reporte(ActionEvent event) {
          switch (operacion) {
            case ACTUALIZAR:
                limpiarControles();
                desactivarControles();
                //cargarDatos();
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                
                btnEditar.setText("Editar");
                btnReporte.setText("Reporte");
                
                imgReporte.setImage(new Image(PACK_IMAGEN + "Reporte.png"));
                imgEditar.setImage(new Image(PACK_IMAGEN + "Editar.png"));
                
                operacion = Operaciones.NINGUNO;
                break;
        }
        
        
    }

   
   
}
