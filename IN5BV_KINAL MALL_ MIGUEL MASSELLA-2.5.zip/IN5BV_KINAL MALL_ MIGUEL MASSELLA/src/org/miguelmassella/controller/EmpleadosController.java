/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.miguelmassella.controller;

import com.jfoenix.controls.JFXDatePicker;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.CallableStatement;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import org.miguelmassella.bean.Administracion;
import org.miguelmassella.bean.Cargos;
import org.miguelmassella.bean.Departamentos;
import org.miguelmassella.bean.Empleados;
import org.miguelmassella.bean.Horarios;
import org.miguelmassella.db.Conexion;
import org.miguelmassella.system.Principal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
/**
 *
 * @author migue
 * @date 17/07/2021
 * @time 01:35:52
 * @code IN5BV
*/
public class EmpleadosController implements Initializable{

     private Principal escenarioPrincipal;
     private final String PACK_IMAGEN = "/org/miguelmassella/resource/image/" ;
     
     
      private ObservableList<Departamentos>listaDepartamentos;
      private ObservableList<Administracion> listaAdministracion;
      private ObservableList<Cargos> listaCargos;
      private ObservableList<Horarios> listaHorarios;
      private ObservableList<Empleados> listaEmpleados;
      
        private enum Operaciones {
        NUEVO, GUARDAR, ACTUALIZAR, ELIMINAR, CANCELAR, NINGUNO
    }
    
    private Operaciones operacion = Operaciones.NINGUNO;
    

     
    @FXML
    private Button btnNuevo;
    @FXML
    private ImageView imgNuevo;
    @FXML
    private Button btnEliminar;
    @FXML
    private ImageView imgEliminar;
    @FXML
    private Button btnEditar;
    @FXML
    private ImageView imgEditar;
    @FXML
    private Button btnReporte;
    @FXML
    private ImageView imgReporte;
    @FXML
    private TableView tblEmpleados;
    @FXML
    private TableColumn colId;
    @FXML
    private TableColumn colNombres;
    @FXML
    private TableColumn colApellidos;
    @FXML
    private TableColumn colEmail;
    @FXML
    private TableColumn colTelefono;
    @FXML
    private TableColumn colContratacion;
    @FXML
    private TableColumn colSueldo;
    @FXML
    private TableColumn colIdDepartamento;
    @FXML
    private TableColumn colIdCargo;
    @FXML
    private TableColumn colIdHorario;
    @FXML
    private TableColumn colIdAdministracion;
    @FXML
    private TextField txtId;
    @FXML
    private TextField txtEmail;
    @FXML
    private TextField txtTelefono;
    @FXML
    private TextField txtNombres;
    @FXML
    private TextField txtApellidos;
    @FXML
    private ComboBox cmbAdministracion;
    @FXML
    private ComboBox cmbHorario;
    @FXML
    private ComboBox cmbDepartamento;
    @FXML
    private ComboBox cmbCargo;
    @FXML
    private TextField txtSueldo;
    @FXML
    private JFXDatePicker dpFechaContratacion;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        Locale locale = new Locale("es", "GT");
        Locale.setDefault(locale);
        
        dpFechaContratacion.setEditable(false);
        
        cargarDatos();
    }

    
    public Principal getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    
    public void setEscenarioPrincipal(Principal escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
    
    
    @FXML
    private void mostrarHorarios(ActionEvent event) {
        escenarioPrincipal.mostrarHorarios();
        
    }

    @FXML
    private void mostrarVistaMenuPrincipal(MouseEvent event) {
        escenarioPrincipal.mostrarMenuPrincipal();
    }
    
    
    
    
     public ObservableList<Empleados> getEmpleados() {
        ArrayList<Empleados> listado = new ArrayList<>();
        
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarEmpleados}");
            System.out.println(pstmt);    
            rs = pstmt.executeQuery();
            
            while(rs.next()) {
                listado.add(new Empleados(
                        rs.getInt("id"), 
                        rs.getString("nombres"), 
                        rs.getString("apellidos"), 
                        rs.getString("email"), 
                        rs.getString("telefono"), 
                        rs.getDate("fechaContratacion"), 
                        rs.getBigDecimal("sueldo"), 
                        rs.getInt("idDepartamento"), 
                        rs.getInt("idCargo"),
                        rs.getInt("idHorario"),
                        rs.getInt("idAdministracion")
                    )
                );
            }
            
            listaEmpleados = FXCollections.observableArrayList(listado);
            
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar consultar la tabla Cuentas por cobrar de la base de datos.");
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
                pstmt.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return listaEmpleados;
     }
    
    
    
  public ObservableList getDepartamentos(){
        
        ArrayList<Departamentos> listado = new ArrayList<Departamentos>();
      
        try{
            CallableStatement stmt;
            stmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarDepartamentos()}");
            ResultSet resultado = stmt.executeQuery();
            
            while (resultado.next()){
                listado.add(new Departamentos(
                        resultado.getInt("id"), 
                        resultado.getString("nombre"))); 
            }
           
            resultado.close();
            stmt.close();
            
        }catch(SQLException e){
            e.printStackTrace();
        }
        
        listaDepartamentos = FXCollections.observableArrayList(listado);
        
        
        return FXCollections.observableArrayList(listado);
    }
    
    
    
    public ObservableList getCargos(){
        
        ArrayList<Cargos> listado = new ArrayList<Cargos>();
      
        try{
            CallableStatement stmt;
            stmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarCargos()}");
            ResultSet resultado = stmt.executeQuery();
            
            while (resultado.next()){
                listado.add(new Cargos(
                        resultado.getInt("id"), 
                        resultado.getString("nombre"))); 
            }
     
            resultado.close();
            stmt.close();
            
        }catch(SQLException e){
            e.printStackTrace();
        }
        
        listaCargos = FXCollections.observableArrayList(listado);
        
        
        return FXCollections.observableArrayList(listado);
    }
    
    

     public ObservableList<Horarios> getHorarios(){
        ArrayList<Horarios> lista = new ArrayList<>();
        
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try{
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarHorarios}");
            System.out.println(pstmt.toString());
            rs = pstmt.executeQuery();
            
            while (rs.next()){
               Horarios horario = new Horarios(
                       rs.getInt("id"),
                       rs.getTime("horarioEntrada"),
                       rs.getTime("horarioSalida"),
                       rs.getBoolean("lunes"),
                       rs.getBoolean("martes"),
                       rs.getBoolean("miercoles"),
                       rs.getBoolean("jueves"),
                       rs.getBoolean("viernes")
                       );
                       
               lista.add(horario);
                       
            }
            
            listaHorarios = FXCollections.observableArrayList(lista);
            
        } catch(SQLException e) {
        System.out.println("\nSe produjo un error al consultar la lista de Horarios");
         e.printStackTrace();
        }catch(Exception e){
          e.printStackTrace();
        }finally{
            try{
                rs.close();
                pstmt.close();
            }catch(Exception e){
              e.printStackTrace();
            }
        }
        return listaHorarios;
    }
    
     public ObservableList<Administracion> getAdministracion() {
        ArrayList<Administracion> listado = new ArrayList<Administracion>();
        PreparedStatement stmt = null;
        ResultSet resultado = null;
        try {
            
            stmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_ListarAdministracion()}");
            resultado = stmt.executeQuery();

            while (resultado.next()) {
                listado.add(new Administracion(
                        resultado.getInt("id"),
                        resultado.getString("direccion"),
                        resultado.getString("telefono")
                )
                );
            }
            listaAdministracion = FXCollections.observableArrayList(listado);
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar consultar la tabla AdministraciÃ³n en la base de datos.");
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                resultado.close();
                stmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return listaAdministracion;
    }
     
     
      public Departamentos buscarDepartamentos(int id) {
        Departamentos departamentos = null;
        
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_BuscarDepartamentos(?)}");
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                departamentos = new Departamentos(
                        rs.getInt("id"), 
                        rs.getString("nombre")
                );
            }
            
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar buscar una Departamento con el ID " + id);
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
                pstmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
                    
        return departamentos;
    }
    
    
    
    
    
    public Cargos buscarCargos(int id) {
        Cargos cargos = null;
        
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_BuscarCargos(?)}");
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                cargos = new Cargos(
                        rs.getInt("id"), 
                        rs.getString("nombre")
                );
            }
            
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar buscar una cargo con el ID " + id);
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
                pstmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
                    
        return cargos;
    }
    
    
     public Horarios buscarHorarios(int id) {
        Horarios horarios = null;
        
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_BuscarHorarios(?)}");
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                horarios = new Horarios(
                        rs.getInt("id"),
                       rs.getTime("horarioEntrada"),
                        rs.getTime("horarioSalida"),
                       rs.getBoolean("lunes"),
                       rs.getBoolean("martes"),
                       rs.getBoolean("miercoles"),
                       rs.getBoolean("jueves"),
                       rs.getBoolean("viernes")
                       
                );
            }
            
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar buscar una Horarios con el ID " + id);
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
                pstmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
                    
        return horarios;
    }
    
     
     public Administracion buscarAdministracion(int id) {
        Administracion administracion = null;
        
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        
        try {
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_BuscarAdministracion(?)}");
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();
            
            while (rs.next()) {
                administracion = new Administracion(
                        rs.getInt("id"), 
                        rs.getString("direccion"), 
                        rs.getString("telefono")
                );
            }
            
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar buscar una Administracion con el ID " + id);
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
                pstmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
                    
        return administracion;
    }
    
     
     public void agregarEmpleados() {
        Empleados empleados = new Empleados();
        empleados.setNombres(txtNombres.getText());
        empleados.setApellidos(txtApellidos.getText());
        empleados.setEmail(txtEmail.getText());
        empleados.setTelefono(txtTelefono.getText());
        empleados.setFechaContratacion(Date.valueOf(dpFechaContratacion.getValue()));
        empleados.setSueldo(new BigDecimal(txtSueldo.getText()));
        
        empleados.setIdDepartamento(((Departamentos)cmbDepartamento.getSelectionModel().getSelectedItem()).getId());
        empleados.setIdCargo(((Cargos) cmbCargo.getSelectionModel().getSelectedItem()).getId());
        empleados.setIdHorario(((Horarios) cmbHorario.getSelectionModel().getSelectedItem()).getId());
        empleados.setIdAdministracion(((Administracion)cmbAdministracion.getSelectionModel().getSelectedItem()).getId());
        
        PreparedStatement pstmt = null;
        
        try {
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_AgregarEmpleados(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
            pstmt.setString(1, empleados.getNombres());
            pstmt.setString(2, empleados.getApellidos());
            pstmt.setString(3, empleados.getEmail());
            pstmt.setString(4, empleados.getTelefono());
            pstmt.setDate(5, empleados.getFechaContratacion());
            pstmt.setBigDecimal(6, empleados.getSueldo());
            pstmt.setInt(7, empleados.getIdDepartamento());
            pstmt.setInt(8, empleados.getIdCargo());
            pstmt.setInt(9, empleados.getIdHorario());
            pstmt.setInt(10, empleados.getIdAdministracion());
            
            System.out.println(pstmt);
            
            pstmt.execute();
            
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar agregar un nuevo Empleado");
            e.printStackTrace();
        } finally {
            try {
                pstmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    
    
    public void editarEmpleados() {
            
        Empleados empleados = new Empleados();
        
        empleados.setId(Integer.parseInt(txtId.getText()));
        empleados.setNombres(txtNombres.getText());
        empleados.setApellidos(txtApellidos.getText());
        empleados.setEmail(txtEmail.getText());
        empleados.setTelefono(txtTelefono.getText());
        empleados.setFechaContratacion(Date.valueOf(dpFechaContratacion.getValue()));
        empleados.setSueldo(new BigDecimal(txtSueldo.getText()));
        empleados.setIdDepartamento(((Departamentos)cmbDepartamento.getSelectionModel().getSelectedItem()).getId());
        empleados.setIdCargo(((Cargos) cmbCargo.getSelectionModel().getSelectedItem()).getId());
        empleados.setIdHorario(((Horarios) cmbHorario.getSelectionModel().getSelectedItem()).getId());
        empleados.setIdAdministracion(((Administracion)cmbAdministracion.getSelectionModel().getSelectedItem()).getId());
        
        PreparedStatement pstmt = null;
        
        try {
            pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_EditarEmpleados(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
            pstmt.setInt(1, empleados.getId());
            pstmt.setString(2, empleados.getNombres());
            pstmt.setString(3, empleados.getApellidos());
            pstmt.setString(4, empleados.getEmail());
            pstmt.setString(5, empleados.getTelefono());
            pstmt.setDate(6, empleados.getFechaContratacion());
            pstmt.setBigDecimal(7, empleados.getSueldo());
            pstmt.setInt(8, empleados.getIdDepartamento());
            pstmt.setInt(9, empleados.getIdCargo());
            pstmt.setInt(10, empleados.getIdHorario());
            pstmt.setInt(11, empleados.getIdAdministracion());
            
            System.out.println(pstmt);
            
            pstmt.execute();
            
        } catch (SQLException e) {
            System.err.println("\nSe produjo un error al intentar agregar un nuevo Empleado");
            e.printStackTrace();
        } finally {
            try {
                pstmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public void eliminarEmpleados() {
        
        if (existeElementoSeleccionado()) {
            
            Empleados empleados = (Empleados) tblEmpleados.getSelectionModel().getSelectedItem();
            
            System.out.println(empleados);
            
            PreparedStatement pstmt = null;
            
            try {
                pstmt = Conexion.getInstance().getConexion().prepareCall("{CALL sp_EliminarEmpleados(?)}");
                
                pstmt.setInt(1,((Empleados) tblEmpleados.getSelectionModel().getSelectedItem()).getId());

                
                System.out.println(pstmt);
                
                pstmt.execute();
         
                
            } catch (SQLException e) {
                System.err.println("\nSe produjo un error al intentar eliminar el registro con el id " + empleados.getId());
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    pstmt.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        
    }
    
    
    
     public boolean existeElementoSeleccionado() {

        if (tblEmpleados.getSelectionModel().getSelectedItem() == null) {
            return false;
        } else {
            return true;
        }
    }
     
      
         @FXML
    private void seleccionarElemento(MouseEvent event) {
        
        
    
        if(existeElementoSeleccionado()) {
            txtId.setText(String.valueOf(((Empleados)tblEmpleados.getSelectionModel().getSelectedItem()).getId()));
            txtNombres.setText(((Empleados)tblEmpleados.getSelectionModel().getSelectedItem()).getNombres());
            txtApellidos.setText(((Empleados)tblEmpleados.getSelectionModel().getSelectedItem()).getApellidos());
            txtEmail.setText(((Empleados)tblEmpleados.getSelectionModel().getSelectedItem()).getEmail());
            txtTelefono.setText(((Empleados)tblEmpleados.getSelectionModel().getSelectedItem()).getTelefono());
            dpFechaContratacion.setValue(((Empleados)tblEmpleados.getSelectionModel().getSelectedItem()).getFechaContratacion().toLocalDate());
            txtSueldo.setText(String.valueOf(((Empleados)tblEmpleados.getSelectionModel().getSelectedItem()).getSueldo()));
            
            cmbDepartamento.getSelectionModel().select(buscarDepartamentos(((Empleados) tblEmpleados.getSelectionModel().getSelectedItem()).getIdDepartamento()));
            cmbCargo.getSelectionModel().select(buscarCargos(((Empleados) tblEmpleados.getSelectionModel().getSelectedItem()).getIdCargo()));
            cmbHorario.getSelectionModel().select(buscarHorarios(((Empleados) tblEmpleados.getSelectionModel().getSelectedItem()).getIdHorario()));
            cmbAdministracion.getSelectionModel().select(buscarAdministracion(((Empleados) tblEmpleados.getSelectionModel().getSelectedItem()).getIdAdministracion()));
        }else {
                Alert vacio = new Alert(Alert.AlertType.ERROR);
                vacio.setTitle("Error");
                vacio.setContentText("Este campo esta vacio");
                vacio.setHeaderText(null);
                vacio.show();
            }
    }
    
    
    
    
      public void cargarDatos() {
         tblEmpleados.setItems(getEmpleados());
         colId.setCellValueFactory(new PropertyValueFactory<Empleados, Integer>("id"));
         colNombres.setCellValueFactory(new PropertyValueFactory<Empleados, String>("nombres"));
         colApellidos.setCellValueFactory(new PropertyValueFactory<Empleados, String>("apellidos"));
         colEmail.setCellValueFactory(new PropertyValueFactory<Empleados, String>("email"));
         colTelefono.setCellValueFactory(new PropertyValueFactory<Empleados, String>("telefono"));
         colContratacion.setCellValueFactory(new PropertyValueFactory<Empleados, Date>("fechaContratacion"));
         colSueldo.setCellValueFactory(new PropertyValueFactory<Empleados, BigDecimal>("sueldo"));
         colIdDepartamento.setCellValueFactory(new PropertyValueFactory<Departamentos, Integer>("idDepartamento"));
         colIdCargo.setCellValueFactory(new PropertyValueFactory<Cargos, Integer>("idCargo"));
         colIdHorario.setCellValueFactory(new PropertyValueFactory<Horarios, Integer>("idHorario"));
         colIdAdministracion.setCellValueFactory(new PropertyValueFactory<Administracion, Integer>("idAdministracion"));

         cmbDepartamento.setItems(getDepartamentos());
         cmbCargo.setItems(getCargos());
         cmbHorario.setItems(getHorarios());
         cmbAdministracion.setItems(getAdministracion());
     }
    
    
     public boolean validarEmail(String email) {

        Pattern pattern = Pattern.compile("^[\\w-]+(\\.[\\w-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    public boolean validarTelefono(String numero) {

        Pattern pattern = Pattern.compile("^[0-9]{8}$");
        Matcher matcher = pattern.matcher(numero);
        return matcher.matches();
    }
    
    
     private void activarControles(){
        
        txtId.setDisable(true);
        txtId.setDisable(false);
        
        txtNombres.setDisable(false);
        txtNombres.setEditable(true);
        
        txtApellidos.setDisable(false);
        txtApellidos.setEditable(true);
        
        txtEmail.setDisable(false);
        txtEmail.setEditable(true);
        
        txtTelefono.setDisable(false);
        txtTelefono.setEditable(true);
        
        dpFechaContratacion.setDisable(false);
        
        txtSueldo.setDisable(false);
        txtSueldo.setEditable(true);

        cmbDepartamento.setDisable(false);
        cmbCargo.setDisable(false);
        cmbHorario.setDisable(false);
        cmbAdministracion.setDisable(false);
        
    }
    
    private void desactivarControles(){
        
        txtId.setDisable(false);
        txtId.setEditable(false);
        
        txtNombres.setDisable(true);
        txtNombres.setEditable(false);
        
        txtApellidos.setDisable(true);
        txtApellidos.setEditable(false);
        
        txtEmail.setDisable(true);
        txtEmail.setEditable(false);
        
        txtTelefono.setDisable(true);
        txtTelefono.setEditable(false);
        
        dpFechaContratacion.setDisable(true);
        
        txtSueldo.setDisable(true);
        txtSueldo.setEditable(false);

        cmbDepartamento.setDisable(true);
        cmbCargo.setDisable(true);
        cmbHorario.setDisable(true);
        cmbAdministracion.setDisable(true);
        
    }
     
     private void limpiarControles() {
         
    txtId.clear();
    txtNombres.clear();
    txtApellidos.clear();
    txtEmail.clear();
    txtTelefono.clear();
    dpFechaContratacion.getEditor().clear();
    txtSueldo.clear();
    
    cmbDepartamento.valueProperty().set(null);
    cmbCargo.valueProperty().set(null);
    cmbHorario.valueProperty().set(null);
    cmbAdministracion.valueProperty().set(null);
}
     
     
    
    
    

    @FXML
    private void nuevo(ActionEvent event) {
         switch (operacion) {
            case NINGUNO:
                activarControles();
                limpiarControles();
                
                btnNuevo.setText("Guardar");
              
                
                btnEditar.setDisable(true);
                
                btnEliminar.setText("Cancelar");
                
                imgNuevo.setImage(new Image( PACK_IMAGEN + "Guardar.png"));
                imgEliminar.setImage(new Image(PACK_IMAGEN + "Cancelar.png"));
                
                btnReporte.setDisable(true);
                
                operacion = Operaciones.GUARDAR;
                break;
                
            case GUARDAR:


                ArrayList<TextField> listaTextField = new ArrayList<>();
                listaTextField.add(txtNombres);
                listaTextField.add(txtApellidos);
                listaTextField.add(txtEmail);
                listaTextField.add(txtTelefono);
                listaTextField.add(txtSueldo);

                ArrayList<JFXDatePicker> listaDatePicker = new ArrayList<>();
                listaDatePicker.add(dpFechaContratacion);

                ArrayList<ComboBox> listaComboBox = new ArrayList<>();
                listaComboBox.add(cmbAdministracion);
                listaComboBox.add(cmbCargo);
                listaComboBox.add(cmbDepartamento);
                listaComboBox.add(cmbHorario);

                if (escenarioPrincipal.validar(listaTextField, listaComboBox)) {
                    
                    if (validarTelefono(txtTelefono.getText())) {
                    
                    if (validarEmail(txtEmail.getText())) {

                    agregarEmpleados();
                    cargarDatos();
                    desactivarControles();
                    limpiarControles();
                    
                    btnNuevo.setText("Nuevo");
                    imgNuevo.setImage(new Image(PACK_IMAGEN + "Agregar.png"));
                    
                    btnEliminar.setText("Eliminar");
                    imgEliminar.setImage(new Image(PACK_IMAGEN + "Eliminar.png"));
                    
                    btnEditar.setDisable(false);
                    btnReporte.setDisable(false);
                    
                    operacion = Operaciones.NINGUNO;
                    } else {
                        Alert vacio = new Alert(Alert.AlertType.ERROR);
                        vacio.setTitle("Error");
                        vacio.setContentText("El email no es valido");
                        vacio.setHeaderText(null);
                        vacio.show();
                    }
                } else {
                    Alert vacio = new Alert(Alert.AlertType.ERROR);
                    vacio.setTitle("Error");
                    vacio.setContentText("El numero no tiene 8 digitos");
                    vacio.setHeaderText(null);
                    vacio.show();
                }
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Por favor llene todos lo campos de textos");
                    alert.show();
                    
                }

                break;
        }
    }

    @FXML
    private void eliminar(ActionEvent event) {
        
         switch (operacion) {
            case GUARDAR:
                
                btnNuevo.setText("Nuevo");
              
                
                
                btnEliminar.setText("Eliminar");
                
                imgNuevo.setImage(new Image(PACK_IMAGEN + "Agregar.png"));
                imgEliminar.setImage(new Image(PACK_IMAGEN + "Eliminar.png"));
                
                btnEditar.setDisable(false);
                btnReporte.setDisable(false);
                
                limpiarControles();
                desactivarControles();
                
                operacion = Operaciones.NINGUNO;
                break;
            case NINGUNO: // Eliminacion
                if (existeElementoSeleccionado()) {
                                        
                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("¿Esta seguro que desea eliminar este registro?");
                    
                    Optional<ButtonType> respuesta = alert.showAndWait();
                    
                    if (respuesta.get() == ButtonType.OK) {
                        eliminarEmpleados();
                        limpiarControles();
                        cargarDatos();                        
                    }
                    
                    
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Antes de continuar, selecciona un registro");
                    alert.show();
                }

                break;
        }
        
        
        
        
        
    }

    @FXML
    private void editar(ActionEvent event) {
           switch (operacion) {
            case NINGUNO:
                if (existeElementoSeleccionado()) {
                    activarControles();
                    
                    btnEditar.setText("Actualizar");
                    
                    
                    btnReporte.setText("Cancelar");
                    imgEditar.setImage(new Image(PACK_IMAGEN + "Guardar.png"));
                    imgReporte.setImage(new Image(PACK_IMAGEN + "Cancelar.png"));
                    
                    btnNuevo.setDisable(true);
                    btnEliminar.setDisable(true);
                    
                    operacion = Operaciones.ACTUALIZAR;
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Debe seleccionar un registro para poder realizar esta accion");
                    alert.show();
                }

                break;
                
            case ACTUALIZAR:
                
                ArrayList<TextField> listaTextField = new ArrayList<>();
                listaTextField.add(txtNombres);
                listaTextField.add(txtApellidos);
                listaTextField.add(txtEmail);
                listaTextField.add(txtTelefono);
                listaTextField.add(txtSueldo);

                ArrayList<JFXDatePicker> listaDatePicker = new ArrayList<>();
                listaDatePicker.add(dpFechaContratacion);

                ArrayList<ComboBox> listaComboBox = new ArrayList<>();
                listaComboBox.add(cmbAdministracion);
                listaComboBox.add(cmbCargo);
                listaComboBox.add(cmbDepartamento);
                listaComboBox.add(cmbHorario);

                if (escenarioPrincipal.validar(listaTextField, listaComboBox)) {
                    
                    if (validarTelefono(txtTelefono.getText())) {
                    
                    if (validarEmail(txtEmail.getText())) {
                    
                    editarEmpleados();
                    limpiarControles();
                   desactivarControles();
                    cargarDatos();

                    btnNuevo.setDisable(false);
                    btnEliminar.setDisable(false);

                    btnEditar.setText("Editar");
                    

                    btnReporte.setText("Reporte");
                    imgReporte.setImage(new Image(PACK_IMAGEN + "Reporte.png"));
                    imgEditar.setImage(new Image(PACK_IMAGEN + "Editar.png"));

                    operacion = Operaciones.NINGUNO;
                    break; 
                    
                    } else {
                        Alert vacio = new Alert(Alert.AlertType.ERROR);
                        vacio.setTitle("Error");
                        vacio.setContentText("El email no es valido");
                        vacio.setHeaderText(null);
                        vacio.show();
                    }
                } else {
                    Alert vacio = new Alert(Alert.AlertType.ERROR);
                    vacio.setTitle("Error");
                    vacio.setContentText("El numero no tiene 8 digitos");
                    vacio.setHeaderText(null);
                    vacio.show();
                }
                    
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("KINAL MALL");
                    alert.setHeaderText(null);
                    alert.setContentText("Por favor llene todos lo campos de textos");
                    alert.show();
                    
                }      
                
        }

        
    
    }

    @FXML
    private void reporte(ActionEvent event) {
        switch (operacion) {
            case ACTUALIZAR:
                limpiarControles();
                desactivarControles();
                //cargarDatos();
                btnNuevo.setDisable(false);
                btnEliminar.setDisable(false);
                
                btnEditar.setText("Editar");
                btnReporte.setText("Reporte");
                
                imgReporte.setImage(new Image(PACK_IMAGEN + "Reporte.png"));
                imgEditar.setImage(new Image(PACK_IMAGEN + "Editar.png"));
                
                operacion = Operaciones.NINGUNO;
                break;
    }
    
    }

   

  

    
}
